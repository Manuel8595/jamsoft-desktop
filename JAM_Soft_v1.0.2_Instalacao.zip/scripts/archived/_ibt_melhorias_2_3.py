"""
Melhoria 2+3:
- Bloqueio anti-fraude (apos envio, ninguem altera)
- Arquivo automatico (concluidas/canceladas saem da lista activa)
Uso: python _ibt_melhorias_2_3.py
"""

path = "transferencias.py"

with open(path, encoding="utf-8") as f:
    c = f.read()

# ============================================================
# 1. Reforcar enviar_transferencia com verificacoes
# ============================================================
antigo_enviar = '''def enviar_transferencia(trans_id, autorizado_por):
    """Marca a transferencia como EM_TRANSITO e baixa o stock na origem."""
    conn = conectar()
    cur = conn.cursor()

    cur.execute("""
        SELECT estado FROM transferencias_filiais WHERE id = ?
    """, (trans_id,))
    r = cur.fetchone()
    if not r:
        conn.close()
        return False, "Transferencia nao encontrada."

    if r[0] != ESTADO_RASCUNHO:
        conn.close()
        return False, f"Estado actual ({r[0]}) nao permite envio."'''

novo_enviar = '''def enviar_transferencia(trans_id, autorizado_por):
    """
    Marca a transferencia como EM_TRANSITO e baixa o stock na origem.
    REGRA ANTI-FRAUDE: depois de enviada, NINGUEM pode alterar.
    """
    conn = conectar()
    cur = conn.cursor()

    cur.execute("""
        SELECT estado FROM transferencias_filiais WHERE id = ?
    """, (trans_id,))
    r = cur.fetchone()
    if not r:
        conn.close()
        return False, "Transferencia nao encontrada."

    # BLOQUEIO: so RASCUNHO pode ser enviado
    if r[0] != ESTADO_RASCUNHO:
        conn.close()
        return False, (f"BLOQUEADO: Estado actual ({r[0]}) nao permite envio.\\n\\n"
                        "Apenas RASCUNHOS podem ser enviados.")'''

if antigo_enviar in c:
    c = c.replace(antigo_enviar, novo_enviar)
    print("OK - enviar_transferencia reforcada")
else:
    print("AVISO - enviar_transferencia nao encontrada (padrao diferente)")

# ============================================================
# 2. Reforcar receber_transferencia
# ============================================================
antigo_receber = '''def receber_transferencia(trans_id, utilizador_nome, itens_recebidos):
    """Confirma a recepcao. itens_recebidos = {item_id: qtd_recebida}"""
    conn = conectar()
    cur = conn.cursor()

    cur.execute("""
        SELECT estado FROM transferencias_filiais WHERE id = ?
    """, (trans_id,))
    r = cur.fetchone()
    if not r or r[0] != ESTADO_EM_TRANSITO:
        conn.close()
        return False, "Estado actual nao permite recepcao."'''

novo_receber = '''def receber_transferencia(trans_id, utilizador_nome, itens_recebidos):
    """
    Confirma a recepcao. itens_recebidos = {item_id: qtd_recebida}
    REGRA ANTI-FRAUDE: a loja receptora so pode CONFIRMAR.
    Nao pode alterar os itens enviados nem o destino.
    """
    conn = conectar()
    cur = conn.cursor()

    cur.execute("""
        SELECT estado FROM transferencias_filiais WHERE id = ?
    """, (trans_id,))
    r = cur.fetchone()
    if not r:
        conn.close()
        return False, "Transferencia nao encontrada."

    # BLOQUEIO: so EM_TRANSITO pode ser recebido
    if r[0] != ESTADO_EM_TRANSITO:
        conn.close()
        return False, (f"BLOQUEADO: Estado actual ({r[0]}) nao permite recepcao.\\n\\n"
                        "Apenas IBTs EM TRANSITO podem ser recebidas.")'''

if antigo_receber in c:
    c = c.replace(antigo_receber, novo_receber)
    print("OK - receber_transferencia reforcada")
else:
    print("AVISO - receber_transferencia nao encontrada")

# ============================================================
# 3. Reforcar cancelar_transferencia
# ============================================================
antigo_cancelar = '''def cancelar_transferencia(trans_id, motivo, utilizador_nome):
    """Cancela uma transferencia em RASCUNHO ou EM_TRANSITO."""
    conn = conectar()
    cur = conn.cursor()

    cur.execute("""
        SELECT estado FROM transferencias_filiais WHERE id = ?
    """, (trans_id,))
    r = cur.fetchone()
    if not r:
        conn.close()
        return False, "Nao encontrada."

    estado = r[0]'''

novo_cancelar = '''def cancelar_transferencia(trans_id, motivo, utilizador_nome):
    """
    Cancela uma transferencia em RASCUNHO ou EM_TRANSITO.
    REGRA ANTI-FRAUDE: IBTs CONCLUIDAS/CANCELADAS nao podem ser canceladas.
    """
    conn = conectar()
    cur = conn.cursor()

    cur.execute("""
        SELECT estado FROM transferencias_filiais WHERE id = ?
    """, (trans_id,))
    r = cur.fetchone()
    if not r:
        conn.close()
        return False, "Nao encontrada."

    estado = r[0]

    # BLOQUEIO: nao pode cancelar CONCLUIDA ou ja CANCELADA
    if estado in (ESTADO_CONCLUIDA, ESTADO_CANCELADA):
        conn.close()
        return False, (f"BLOQUEADO: IBT {estado} nao pode ser cancelada.\\n\\n"
                        "Apenas RASCUNHOS e EM_TRANSITO podem ser cancelados.")'''

if antigo_cancelar in c:
    c = c.replace(antigo_cancelar, novo_cancelar)
    print("OK - cancelar_transferencia reforcada")
else:
    print("AVISO - cancelar_transferencia nao encontrada")

# ============================================================
# 4. listar_transferencias: adicionar parametro incluir_arquivadas
# ============================================================
antigo_listar = '''def listar_transferencias(estado=None, limite=100):
    conn = conectar()
    cur = conn.cursor()
    if estado:
        cur.execute("""
            SELECT id, referencia, data_criacao, data_envio, data_recepcao,
                   farmacia_origem_nome, farmacia_destino_nome,
                   total_itens, total_quantidade, valor_estimado,
                   estado, utilizador_criou_nome, autorizado_por
            FROM transferencias_filiais WHERE estado = ?
            ORDER BY id DESC LIMIT ?
        """, (estado, limite))
    else:
        cur.execute("""
            SELECT id, referencia, data_criacao, data_envio, data_recepcao,
                   farmacia_origem_nome, farmacia_destino_nome,
                   total_itens, total_quantidade, valor_estimado,
                   estado, utilizador_criou_nome, autorizado_por
            FROM transferencias_filiais ORDER BY id DESC LIMIT ?
        """, (limite,))
    resultado = cur.fetchall()
    conn.close()
    return resultado'''

novo_listar = '''def listar_transferencias(estado=None, limite=100, incluir_arquivadas=False):
    """
    Lista transferencias.
    
    Por defeito, NAO mostra as CONCLUIDAS nem CANCELADAS (arquivadas).
    Para ver as arquivadas, passa incluir_arquivadas=True.
    """
    conn = conectar()
    cur = conn.cursor()

    # Estados arquivados (nao aparecem por defeito)
    arquivados = (ESTADO_CONCLUIDA, ESTADO_CANCELADA)

    if estado:
        # Se pediu estado especifico, mostrar tudo desse estado
        cur.execute("""
            SELECT id, referencia, data_criacao, data_envio, data_recepcao,
                   farmacia_origem_nome, farmacia_destino_nome,
                   total_itens, total_quantidade, valor_estimado,
                   estado, utilizador_criou_nome, autorizado_por
            FROM transferencias_filiais WHERE estado = ?
            ORDER BY id DESC LIMIT ?
        """, (estado, limite))
    elif incluir_arquivadas:
        # Mostrar TODAS (incluindo arquivadas)
        cur.execute("""
            SELECT id, referencia, data_criacao, data_envio, data_recepcao,
                   farmacia_origem_nome, farmacia_destino_nome,
                   total_itens, total_quantidade, valor_estimado,
                   estado, utilizador_criou_nome, autorizado_por
            FROM transferencias_filiais ORDER BY id DESC LIMIT ?
        """, (limite,))
    else:
        # So as activas (nao arquivadas)
        cur.execute("""
            SELECT id, referencia, data_criacao, data_envio, data_recepcao,
                   farmacia_origem_nome, farmacia_destino_nome,
                   total_itens, total_quantidade, valor_estimado,
                   estado, utilizador_criou_nome, autorizado_por
            FROM transferencias_filiais
            WHERE estado NOT IN (?, ?)
            ORDER BY id DESC LIMIT ?
        """, (ESTADO_CONCLUIDA, ESTADO_CANCELADA, limite))

    resultado = cur.fetchall()
    conn.close()
    return resultado'''

if antigo_listar in c:
    c = c.replace(antigo_listar, novo_listar)
    print("OK - listar_transferencias com filtro de arquivadas")
else:
    print("AVISO - listar_transferencias nao encontrada")

# ============================================================
# 5. Adicionar estados "ARQUIVADO" ao filtro da lista IBT
# ============================================================
antigo_estados = '''    estados = ["TODOS", ESTADO_RASCUNHO, ESTADO_EM_TRANSITO,
               ESTADO_RECEBIDA_PARCIAL, ESTADO_CONCLUIDA,
               ESTADO_CANCELADA, ESTADO_DIVERGENCIA]'''

novo_estados = '''    estados = ["TODOS (activas)", "TODOS (com arquivadas)",
               ESTADO_RASCUNHO, ESTADO_EM_TRANSITO,
               ESTADO_RECEBIDA_PARCIAL, ESTADO_CONCLUIDA,
               ESTADO_CANCELADA, ESTADO_DIVERGENCIA]'''

if antigo_estados in c:
    c = c.replace(antigo_estados, novo_estados)
    print("OK - estados do filtro actualizados")
else:
    print("AVISO - lista de estados nao encontrada")

# ============================================================
# 6. Actualizar a funcao carregar() para interpretar o novo filtro
# ============================================================
antigo_carregar = '''    def carregar():
        for i in tree.get_children():
            tree.delete(i)

        estado = filtro_var.get()
        estado_f = None if estado == "TODOS" else estado

        for t in listar_transferencias(estado_f, 200):'''

novo_carregar = '''    def carregar():
        for i in tree.get_children():
            tree.delete(i)

        estado = filtro_var.get()

        if estado.startswith("TODOS (activas"):
            estado_f = None
            incluir_arquivadas = False
        elif estado.startswith("TODOS (com arquiv"):
            estado_f = None
            incluir_arquivadas = True
        else:
            estado_f = estado
            incluir_arquivadas = True

        for t in listar_transferencias(estado_f, 200, incluir_arquivadas):'''

if antigo_carregar in c:
    c = c.replace(antigo_carregar, novo_carregar)
    print("OK - funcao carregar actualizada")
else:
    print("AVISO - funcao carregar nao encontrada")

# ============================================================
# 7. Bloquear botao "Continuar" se nao for RASCUNHO (ja existe)
#    e Bloquear "Receber" se nao for EM_TRANSITO (ja existe)
#    Bloquear edicao se IBT nao for RASCUNHO (verificar em abrir_nova_ibt)
# ============================================================
antigo_nova = '''def abrir_nova_ibt(utilizador, parent, callback=None, trans_id_existente=None):
    janela = Toplevel(parent)
    if trans_id_existente:
        janela.title("Continuar Transferencia (IBT)")
    else:
        janela.title("Nova Transferencia (IBT)")'''

novo_nova = '''def abrir_nova_ibt(utilizador, parent, callback=None, trans_id_existente=None):
    # BLOQUEIO ANTI-FRAUDE: se for para continuar, verificar que ainda e RASCUNHO
    if trans_id_existente:
        pode_editar, estado_atual = pode_editar_transferencia(trans_id_existente)
        if not pode_editar:
            messagebox.showerror("BLOQUEADO",
                f"Esta IBT nao pode ser editada.\\n\\n"
                f"Estado actual: {estado_atual}\\n\\n"
                "Apenas RASCUNHOS podem ser editados.")
            return

    janela = Toplevel(parent)
    if trans_id_existente:
        janela.title("Continuar Transferencia (IBT)")
    else:
        janela.title("Nova Transferencia (IBT)")'''

if antigo_nova in c:
    c = c.replace(antigo_nova, novo_nova)
    print("OK - abrir_nova_ibt com bloqueio anti-fraude")
else:
    print("AVISO - abrir_nova_ibt nao encontrada")

# ============================================================
# 8. Bloquear "gravar_rascunho" se IBT nao for RASCUNHO
# ============================================================
antigo_rasc = '''    def gravar_rascunho():
        if not carrinho:
            messagebox.showwarning("Aviso", "Adicione pelo menos um produto.")
            return

        did, dcod, dnome, erro = parse_destino()'''

novo_rasc = '''    def gravar_rascunho():
        # BLOQUEIO: se estiver a editar rascunho, verificar estado
        if trans_id_existente:
            pode_editar, estado_atual = pode_editar_transferencia(trans_id_existente)
            if not pode_editar:
                messagebox.showerror("BLOQUEADO",
                    f"Esta IBT ja foi enviada ou concluida.\\n\\n"
                    f"Estado actual: {estado_atual}\\n\\n"
                    "Nao pode mais alterar.")
                return

        if not carrinho:
            messagebox.showwarning("Aviso", "Adicione pelo menos um produto.")
            return

        did, dcod, dnome, erro = parse_destino()'''

if antigo_rasc in c:
    c = c.replace(antigo_rasc, novo_rasc)
    print("OK - gravar_rascunho com bloqueio")
else:
    print("AVISO - gravar_rascunho nao encontrada")

# ============================================================
# Gravar
# ============================================================
with open(path, "w", encoding="utf-8") as f:
    f.write(c)

print()
print("=" * 60)
print("OK - Melhorias 2 + 3 aplicadas!")
print("=" * 60)