"""
Adiciona colunas uuid e sincronizado nas tabelas que faltam.
Uso: python _adicionar_sync_tabelas.py
"""

from database import conectar


TABELAS = [
    "itens_venda",
    "produtos",
    "lotes",
    "clientes",
    "facturas",
    "devolucoes",
    "turnos_caixa",
    "dias_operacao",
]


def main():
    conn = conectar()
    cur = conn.cursor()
    
    for t in TABELAS:
        print(f"A processar: {t}")
        cur.execute(f"PRAGMA table_info({t})")
        cols = [c[1] for c in cur.fetchall()]
        
        if "uuid" not in cols:
            try:
                cur.execute(f"ALTER TABLE {t} ADD COLUMN uuid TEXT")
                print(f"  + uuid adicionado")
            except Exception as e:
                print(f"  X uuid: {e}")
        else:
            print(f"  . uuid ja existe")
        
        if "terminal_id" not in cols:
            try:
                cur.execute(f"ALTER TABLE {t} ADD COLUMN terminal_id TEXT")
                print(f"  + terminal_id adicionado")
            except Exception as e:
                print(f"  X terminal_id: {e}")
        else:
            print(f"  . terminal_id ja existe")
        
        if "sincronizado" not in cols:
            try:
                cur.execute(f"ALTER TABLE {t} ADD COLUMN sincronizado INTEGER DEFAULT 0")
                print(f"  + sincronizado adicionado")
            except Exception as e:
                print(f"  X sincronizado: {e}")
        else:
            print(f"  . sincronizado ja existe")
        
        print()
    
    conn.commit()
    conn.close()
    print("Concluido!")


if __name__ == "__main__":
    main()