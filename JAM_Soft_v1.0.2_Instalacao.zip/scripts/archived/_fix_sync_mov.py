path = "sincronizacao.py"

with open(path, encoding="utf-8") as f:
    c = f.read()

# 1. Adicionar colunas no SELECT
antigo_select = """SELECT uuid, data, tipo, valor, descricao,
                   utilizador_nome, terminal_id
            FROM movimentos_caixa WHERE id = ?"""

novo_select = """SELECT uuid, data, tipo, valor, descricao,
                   utilizador_nome, terminal_id,
                   autorizado_por, numero_documento
            FROM movimentos_caixa WHERE id = ?"""

if antigo_select in c:
    c = c.replace(antigo_select, novo_select)
    print("OK: SELECT actualizado")
else:
    print("AVISO: SELECT nao encontrado - verificar manualmente")

# 2. Adicionar no payload
antigo_payload = '"utilizador_nome": r[5],\n            }\n\n    # ============ ITEM DE VENDA ============'

novo_payload = '"utilizador_nome": r[5],\n                "autorizado_por": r[7],\n                "numero_documento": r[8],\n            }\n\n    # ============ ITEM DE VENDA ============'

if antigo_payload in c:
    c = c.replace(antigo_payload, novo_payload)
    print("OK: payload actualizado")
else:
    print("AVISO: payload nao encontrado - verificar manualmente")

with open(path, "w", encoding="utf-8") as f:
    f.write(c)

print("Ficheiro guardado")