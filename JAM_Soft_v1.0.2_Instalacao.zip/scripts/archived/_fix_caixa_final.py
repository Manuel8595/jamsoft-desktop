import re

path = "caixa.py"

with open(path, encoding="utf-8") as f:
    conteudo = f.read()

# 1. Corrigir strings f-strings quebradas
# Padrão: "texto\n(quebra real)    continuação"
# Substituir por: "texto\\ncontinuação"

# Regex para encontrar strings com quebras reais
def _corrigir_string(m):
    return '"' + m.group(1).replace("\n", "\\n") + '"'

# Aplicar em strings f-strings quebradas
conteudo = re.sub(r'f"([^"]*?\n[^"]*?)"', lambda m: 'f"' + m.group(1).replace("\n", "\\n") + '"', conteudo)
conteudo = re.sub(r'"([^"]*?\n[^"]*?)"', _corrigir_string, conteudo)

# Aplicar múltiplas vezes (nested)
for _ in range(10):
    novo = re.sub(r'f"([^"]*?\n[^"]*?)"', lambda m: 'f"' + m.group(1).replace("\n", "\\n") + '"', conteudo)
    novo = re.sub(r'"([^"]*?\n[^"]*?)"', _corrigir_string, novo)
    if novo == conteudo:
        break
    conteudo = novo

with open(path, "w", encoding="utf-8") as f:
    f.write(conteudo)

print("OK - corrigido")