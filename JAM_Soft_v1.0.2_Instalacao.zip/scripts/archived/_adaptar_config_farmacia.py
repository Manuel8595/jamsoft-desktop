"""
Adapta o config_farmacia.py para:
1. Gravar a farmacia localmente
2. Registar automaticamente no Supabase
3. Mostrar confirmacao ao utilizador

Uso: python _adaptar_config_farmacia.py
"""

path = "config_farmacia.py"

with open(path, encoding="utf-8") as f:
    c = f.read()

# ============================================================
# 1. Adicionar import do gerar_uuid (se nao existir)
# ============================================================
if "from identidade import" in c and "gerar_uuid" not in c:
    c = c.replace(
        "from identidade import (configurar_farmacia, configurar_terminal,",
        "from identidade import (configurar_farmacia, configurar_terminal,\n                          gerar_uuid,"
    )
    print("OK - import gerar_uuid adicionado")

# ============================================================
# 2. Adicionar funcao _registar_farmacia_na_nuvem
# ============================================================
funcao_nuvem = '''

# ============================================================
# ============ REGISTAR FARMACIA NA NUVEM ====================
# ============================================================

def _registar_farmacia_na_nuvem(codigo, nome, nif, endereco,
                                   telefone, email, responsavel, notas):
    """
    Regista a farmacia no Supabase (tabela `farmacias`).
    Retorna (sucesso, mensagem).
    """
    try:
        import requests
        from config_cloud import (SUPABASE_URL,
                                    SUPABASE_PUBLISHABLE_KEY,
                                    SYNC_TIMEOUT)
        from datetime import datetime
        from identidade import gerar_uuid

        headers = {
            "apikey": SUPABASE_PUBLISHABLE_KEY,
            "Authorization": f"Bearer {SUPABASE_PUBLISHABLE_KEY}",
            "Content-Type": "application/json",
            "Prefer": "resolution=merge-duplicates,return=minimal",
        }

        # Verificar se ja existe (pelo codigo)
        url_get = f"{SUPABASE_URL}/rest/v1/farmacias?codigo=eq.{codigo}&select=id,uuid"
        r = requests.get(url_get, headers=headers, timeout=SYNC_TIMEOUT)

        if r.status_code == 200:
            existentes = r.json()
            if existentes:
                # Ja existe - so actualizar
                farm_uuid = existentes[0].get("uuid") or gerar_uuid()
                payload = {
                    "uuid": farm_uuid,
                    "codigo": codigo,
                    "nome": nome,
                    "nif": nif,
                    "endereco": endereco,
                    "telefone": telefone,
                    "email": email,
                    "responsavel": responsavel,
                    "notas": notas,
                    "activo": True,
                }
                url_upd = f"{SUPABASE_URL}/rest/v1/farmacias?codigo=eq.{codigo}"
                r2 = requests.patch(url_upd, headers=headers, json=payload,
                                      timeout=SYNC_TIMEOUT)
                if 200 <= r2.status_code < 300:
                    return True, f"Farmácia '{nome}' actualizada na nuvem."
                else:
                    return False, f"Erro a actualizar: HTTP {r2.status_code}"

        # Nao existe - criar nova
        farm_uuid = gerar_uuid()
        payload = {
            "uuid": farm_uuid,
            "codigo": codigo,
            "nome": nome,
            "nif": nif,
            "endereco": endereco,
            "telefone": telefone,
            "email": email,
            "responsavel": responsavel,
            "notas": notas,
            "activo": True,
            "criado_em": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }

        url_post = f"{SUPABASE_URL}/rest/v1/farmacias"
        headers_post = dict(headers)
        headers_post["Prefer"] = "return=minimal"

        r3 = requests.post(url_post, headers=headers_post, json=payload,
                             timeout=SYNC_TIMEOUT)

        if 200 <= r3.status_code < 300:
            return True, f"Farmácia '{nome}' registada na nuvem."
        elif r3.status_code == 409:
            return True, f"Farmácia '{nome}' ja existia na nuvem."
        else:
            return False, f"HTTP {r3.status_code}: {r3.text[:100]}"

    except ImportError as e:
        return False, f"Modulo em falta: {e}"
    except Exception as e:
        return False, f"Erro: {e}"
'''

# Adicionar a funcao no fim do ficheiro (antes do ultimo parenteses)
if "_registar_farmacia_na_nuvem" not in c:
    c = c + funcao_nuvem
    print("OK - funcao _registar_farmacia_na_nuvem adicionada")

# ============================================================
# 3. Chamar a funcao dentro do gravar()
# ============================================================

# Padrao: depois de configurar_terminal() e antes de registar_auditoria()
padrao_antigo = '''            # Configurar terminal
            configurar_terminal(term_codigo, term_nome)
            
            # Auditoria'''

padrao_novo = '''            # Configurar terminal
            configurar_terminal(term_codigo, term_nome)
            
            # Registar na nuvem (Supabase)
            sucesso_nuvem, msg_nuvem = _registar_farmacia_na_nuvem(
                codigo, nome, nif, endereco, telefone,
                email, responsavel, notas
            )
            
            # Auditoria'''

if padrao_antigo in c:
    c = c.replace(padrao_antigo, padrao_novo)
    print("OK - chamada a nuvem adicionada no gravar()")
else:
    print("AVISO - padrao do gravar() nao encontrado - verificar manualmente")

# ============================================================
# 4. Actualizar a mensagem de sucesso
# ============================================================

padrao_msg_antigo = '''            messagebox.showinfo("Sucesso",
                f"Farmácia configurada!\\n\\n"
                f"Código: {codigo}\\n"
                f"Nome: {nome}\\n"
                f"Terminal: {term_codigo}\\n\\n"
                f"Esta configuração é única em toda a rede.")'''

padrao_msg_novo = '''            msg_extra = ""
            if sucesso_nuvem:
                msg_extra = f"\\n\\n☁️ {msg_nuvem}"
            else:
                msg_extra = f"\\n\\n⚠️ Nuvem: {msg_nuvem}\\n(Vai tentar novamente no próximo sync)"
            
            messagebox.showinfo("Sucesso",
                f"Farmácia configurada!\\n\\n"
                f"Código: {codigo}\\n"
                f"Nome: {nome}\\n"
                f"Terminal: {term_codigo}\\n"
                f"Esta configuração é única em toda a rede."
                f"{msg_extra}")'''

if padrao_msg_antigo in c:
    c = c.replace(padrao_msg_antigo, padrao_msg_novo)
    print("OK - mensagem de sucesso actualizada")
else:
    print("AVISO - padrao da mensagem nao encontrado - verificar manualmente")

# ============================================================
# Gravar
# ============================================================
with open(path, "w", encoding="utf-8") as f:
    f.write(c)

print()
print("=" * 60)
print("OK - config_farmacia.py adaptado!")
print("=" * 60)