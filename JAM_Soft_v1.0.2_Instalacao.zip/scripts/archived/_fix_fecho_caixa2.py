path = "caixa.py"

with open(path, encoding="utf-8") as f:
    c = f.read()

# Corrigir todas as strings f-strings que ficaram quebradas
# O padrão é: f"texto\n    continuação" (quebra real)
# Devia ser:  f"texto\ncontinuação" (escape \n)

# Substituir quebras reais entre " e "
c = c.replace('f"Nao e possivel fechar!\n\n"', 'f"Nao e possivel fechar!\\n\\n"')
c = c.replace('f"FALTA em dinheiro: {formatar_kz(abs(diff_cash))}\n\n"', 
              'f"FALTA em dinheiro: {formatar_kz(abs(diff_cash))}\\n\\n"')
c = c.replace('f"Reconte o dinheiro antes de fechar."', 
              'f"Reconte o dinheiro antes de fechar."')
c = c.replace('"Ha sobra no caixa.\n\n"', '"Ha sobra no caixa.\\n\\n"')
c = c.replace('"Tem de escrever o motivo nas observações."',
              '"Tem de escrever o motivo nas observações."')
c = c.replace('f"Fechar o caixa?\n\n"', 'f"Fechar o caixa?\\n\\n"')
c = c.replace('f"Cash: {formatar_kz(total_cash)}\n"', 
              'f"Cash: {formatar_kz(total_cash)}\\n"')
c = c.replace('f"TPA:  {formatar_kz(total_tpa)} ({num_taloes} taloes)\n"',
              'f"TPA:  {formatar_kz(total_tpa)} ({num_taloes} taloes)\\n"')
c = c.replace('f"Depositar: {valor_depositar_var.get()}"',
              'f"Depositar: {valor_depositar_var.get()}"')
c = c.replace('f"CAIXA #{cx_id} FECHADO!\n\n"',
              'f"CAIXA #{cx_id} FECHADO!\\n\\n"')
c = c.replace('f"Cash: {formatar_kz(total_cash)}\n"',
              'f"Cash: {formatar_kz(total_cash)}\\n"')
c = c.replace('f"TPA:  {formatar_kz(total_tpa)}\n"',
              'f"TPA:  {formatar_kz(total_tpa)}\\n"')
c = c.replace('f"Depositar: {valor_depositar_var.get()}\n"',
              'f"Depositar: {valor_depositar_var.get()}\\n"')
c = c.replace('f"Fundo ao gerente: {formatar_kz(fundo_inicial)}\n\n"',
              'f"Fundo ao gerente: {formatar_kz(fundo_inicial)}\\n\\n"')
c = c.replace('f"Autorizado por: {nome_gerente}"',
              'f"Autorizado por: {nome_gerente}"')

with open(path, "w", encoding="utf-8") as f:
    f.write(c)

print("OK - ficheiro corrigido")