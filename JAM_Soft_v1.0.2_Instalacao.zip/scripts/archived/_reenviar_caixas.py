from database import conectar

conn = conectar()
cur = conn.cursor()

# 1. Apagar caixas com erro da fila
cur.execute("DELETE FROM fila_sincronizacao WHERE tipo = 'CAIXA'")
print(f"Apagados da fila: {cur.rowcount}")

# 2. Marcar caixas para sincronizar
cur.execute("UPDATE caixas SET sincronizado = 0")
print(f"Caixas marcados: {cur.rowcount}")

conn.commit()
conn.close()

print()
print("OK - corre F9 agora")