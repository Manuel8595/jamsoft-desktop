from database import conectar

conn = conectar()
cur = conn.cursor()

# Apagar produtos da fila
cur.execute("DELETE FROM fila_sincronizacao WHERE tipo = 'PRODUTO'")
print(f"Produtos removidos da fila: {cur.rowcount}")

# Marcar produtos para sincronizar
cur.execute("UPDATE produtos SET sincronizado = 0")
print(f"Produtos marcados: {cur.rowcount}")

conn.commit()
conn.close()

print()
print("OK - corre F9 agora")