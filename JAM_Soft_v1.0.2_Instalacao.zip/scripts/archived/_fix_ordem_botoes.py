"""
Corrige a ordem dos pack() na Lista IBT.
Move o frame_btn para ANTES do frame_tab.
Uso: python _fix_ordem_botoes.py
"""

path = "transferencias.py"

with open(path, encoding="utf-8") as f:
    c = f.read()

# Encontrar o bloco dos botoes
bloco_botoes = '''    # ============================================================
    # BARRA DE BOTOES FIXA EM BAIXO
    # ============================================================
    frame_btn = Frame(janela, bg=COR_CARD, height=80)
    frame_btn.pack(fill=X, side=BOTTOM)
    frame_btn.pack_propagate(False)

    estilo = {"font": ("Segoe UI", 10, "bold"),
              "bd": 0, "cursor": "hand2", "fg": "white",
              "width": 15, "height": 2}

    Button(frame_btn, text="▶️ Continuar",
           bg=COR_DOURADO, fg="#0f172a",
           command=continuar_rascunho, **estilo).pack(side=LEFT, padx=6, pady=15)
    Button(frame_btn, text="🔍 Ver Detalhes",
           bg=COR_AZUL, command=ver_detalhes, **estilo).pack(side=LEFT, padx=6, pady=15)
    Button(frame_btn, text="📥 Receber",
           bg=COR_VERDE, command=receber, **estilo).pack(side=LEFT, padx=6, pady=15)
    Button(frame_btn, text="🔄 Actualizar",
           bg="#64748b", command=carregar, **estilo).pack(side=LEFT, padx=6, pady=15)
    Button(frame_btn, text="❌ Fechar",
           bg=COR_VERMELHO,
           command=janela.destroy, **estilo).pack(side=RIGHT, padx=6, pady=15)
'''

# Remover o bloco dos botoes do lugar actual
if bloco_botoes in c:
    c = c.replace(bloco_botoes, "")
    print("OK - bloco dos botoes removido do lugar antigo")
else:
    print("AVISO - bloco dos botoes nao encontrado (1)")

# Encontrar o marcador da frame_tab
marcador = '''    frame_tab = Frame(janela, bg=COR_FUNDO)
    frame_tab.pack(fill=BOTH, expand=True, padx=20, pady=10)'''

if marcador in c:
    # Inserir o bloco dos botoes ANTES da frame_tab
    novo = bloco_botoes + "\n" + marcador
    c = c.replace(marcador, novo)
    print("OK - bloco dos botoes movido para antes da tabela")
else:
    print("AVISO - frame_tab nao encontrado")

with open(path, "w", encoding="utf-8") as f:
    f.write(c)

print()
print("=" * 60)
print("OK - Ordem dos pack() corrigida!")
print("=" * 60)