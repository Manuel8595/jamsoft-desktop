path = "caixa.py"

with open(path, encoding="utf-8") as f:
    conteudo = f.read()

# ─── 1. Substituir botões no menu ───
conteudo = conteudo.replace(
    'Button(frame_botoes, text="Sangria (Retirar)", bg=COR_PERIGO,\n'
    '               command=lambda: sangria(cx_id, utilizador_logado, janela),\n'
    '               **estilo).grid(row=0, column=0, padx=5, pady=5)',
    'Button(frame_botoes, text="🔴 Saida de Caixa", bg=COR_PERIGO,\n'
    '               command=lambda: saida_caixa(cx_id, utilizador_logado, janela),\n'
    '               **estilo).grid(row=0, column=0, padx=5, pady=5)'
)

conteudo = conteudo.replace(
    'Button(frame_botoes, text="Reforco (Adicionar)", bg=COR_VERDE,\n'
    '               command=lambda: reforco(cx_id, utilizador_logado, janela),\n'
    '               **estilo).grid(row=0, column=1, padx=5, pady=5)',
    'Button(frame_botoes, text="🟢 Entrada de Caixa", bg=COR_VERDE,\n'
    '               command=lambda: entrada_caixa(cx_id, utilizador_logado, janela),\n'
    '               **estilo).grid(row=0, column=1, padx=5, pady=5)'
)

# ─── 2. Substituir função sangria por saida_caixa ───
import re

nova_saida = '''def saida_caixa(cx_id, utilizador_logado, parent):
    """Regista uma saida de caixa (despesa)."""
    janela = Toplevel(parent)
    janela.title("Saida de Caixa")
    janela.geometry("550x650")
    janela.configure(bg=COR_FUNDO)
    janela.transient(parent)
    janela.grab_set()
    janela.update_idletasks()
    x = (janela.winfo_screenwidth() - 550) // 2
    y = (janela.winfo_screenheight() - 650) // 2
    janela.geometry(f"550x650+{x}+{y}")
    
    header = Frame(janela, bg=COR_PERIGO, height=80)
    header.pack(fill=X)
    header.pack_propagate(False)
    Label(header, text="SAIDA DE CAIXA", font=("Segoe UI", 18, "bold"),
          bg=COR_PERIGO, fg="white").pack(pady=(15, 0))
    Label(header, text="Registar saida de dinheiro (despesa)",
          font=("Segoe UI", 10, "italic"),
          bg=COR_PERIGO, fg="#ffe4e6").pack()
    
    body = Frame(janela, bg=COR_FUNDO)
    body.pack(fill=BOTH, expand=True, padx=30, pady=20)
    
    Label(body, text="Valor (Kz):", font=("Segoe UI", 12, "bold"),
          bg=COR_FUNDO, fg=COR_TEXTO).pack(anchor=W, pady=(10, 5))
    entry_valor = Entry(body, font=("Segoe UI", 16), width=20,
                         justify=CENTER, bd=2, relief=SOLID)
    entry_valor.pack(pady=5, ipady=8)
    entry_valor.focus()
    
    Label(body, text="Categoria:", font=("Segoe UI", 12, "bold"),
          bg=COR_FUNDO, fg=COR_TEXTO).pack(anchor=W, pady=(15, 5))
    CATEGORIAS_SAIDA = ["Compra de material", "Agua/Luz/Internet",
                        "Combustivel", "Pagamento fornecedor",
                        "Manutencao", "Outro"]
    categoria_var = StringVar(value=CATEGORIAS_SAIDA[0])
    combo_cat = ttk.Combobox(body, textvariable=categoria_var,
                                values=CATEGORIAS_SAIDA, state="readonly",
                                font=("Segoe UI", 11), width=40)
    combo_cat.pack(pady=5, ipady=4)
    
    Label(body, text="Motivo / Descricao: (obrigatorio)",
          font=("Segoe UI", 12, "bold"),
          bg=COR_FUNDO, fg=COR_TEXTO).pack(anchor=W, pady=(15, 5))
    entry_desc = Entry(body, font=("Segoe UI", 11), width=45,
                        bd=2, relief=SOLID)
    entry_desc.pack(pady=5, ipady=6)
    
    aviso_var = StringVar(value="")
    Label(body, textvariable=aviso_var, font=("Segoe UI", 10, "bold"),
          bg=COR_FUNDO, fg=COR_ALERTA).pack(pady=(10, 5))
    
    def confirmar():
        try:
            valor_txt = entry_valor.get().replace(".", "").replace(",", ".")
            valor = float(valor_txt)
            if valor <= 0:
                messagebox.showwarning("Aviso", "O valor deve ser positivo.")
                return
            descricao = entry_desc.get().strip()
            if not descricao:
                messagebox.showwarning("Aviso", "Escreva o motivo da saida.")
                return
            categoria = categoria_var.get()
            texto_desc = f"[{categoria}] {descricao}"
            autorizado_por = None
            if valor > 10000:
                ok, nome = _pedir_autorizacao_gerente(parent, f"Saida de {formatar_kz(valor)}")
                if not ok:
                    return
                autorizado_por = nome
                texto_desc += f" | Autorizado por: {nome}"
            registar_movimento_caixa(cx_id, "SAIDA", valor, texto_desc,
                                       utilizador_logado["id"], utilizador_logado["nome"])
            registar_auditoria(utilizador_logado["id"], utilizador_logado["nome"],
                                "SAIDA CAIXA",
                                f"Caixa #{cx_id} | {formatar_kz(valor)} | {categoria} | {descricao}")
            messagebox.showinfo("Sucesso",
                f"Saida registada!\\n\\nValor: {formatar_kz(valor)}\\n"
                f"Categoria: {categoria}\\nDescricao: {descricao}")
            janela.destroy()
            parent.destroy()
            abrir_caixa_menu(utilizador_logado)
        except ValueError:
            messagebox.showerror("Erro", "Digite um valor valido.")
    
    def verificar_valor(event=None):
        try:
            valor_txt = entry_valor.get().replace(".", "").replace(",", ".")
            valor = float(valor_txt)
            if valor > 10000:
                aviso_var.set("Sera necessaria autorizacao do gerente (>10.000 Kz)")
            else:
                aviso_var.set("")
        except ValueError:
            aviso_var.set("")
    
    entry_valor.bind('<KeyRelease>', verificar_valor)
    entry_valor.bind('<Return>', lambda e: entry_desc.focus())
    entry_desc.bind('<Return>', lambda e: confirmar())
    
    frame_btn = Frame(body, bg=COR_FUNDO)
    frame_btn.pack(pady=25)
    Button(frame_btn, text="Confirmar Saida", font=("Segoe UI", 13, "bold"),
           bg=COR_PERIGO, fg="white", width=20, height=2, bd=0, cursor="hand2",
           command=confirmar).pack(side=LEFT, padx=5)
    Button(frame_btn, text="Cancelar", font=("Segoe UI", 11),
           bg="#6b7280", fg="white", width=15, height=2, bd=0, cursor="hand2",
           command=janela.destroy).pack(side=LEFT, padx=5)


def _pedir_autorizacao_gerente(parent, motivo):
    """Pede senha do gerente/admin. Retorna (ok, nome)."""
    resultado = {"ok": False, "nome": None}
    auth = Toplevel(parent)
    auth.title("Autorizacao do Gerente")
    auth.geometry("500x450")
    auth.configure(bg=COR_FUNDO)
    auth.transient(parent)
    auth.grab_set()
    auth.update_idletasks()
    x = (auth.winfo_screenwidth() - 500) // 2
    y = (auth.winfo_screenheight() - 450) // 2
    auth.geometry(f"500x450+{x}+{y}")
    header = Frame(auth, bg="#ea580c", height=70)
    header.pack(fill=X)
    header.pack_propagate(False)
    Label(header, text="AUTORIZACAO NECESSARIA", font=("Segoe UI", 15, "bold"),
          bg="#ea580c", fg="white").pack(pady=20)
    Label(auth, text=motivo, font=("Segoe UI", 11),
          bg=COR_FUNDO, fg=COR_TEXTO, wraplength=460,
          justify=CENTER).pack(pady=(20, 15), padx=20)
    card = Frame(auth, bg=COR_CARD, highlightthickness=1,
                  highlightbackground="#334155")
    card.pack(padx=30, fill=X)
    frame = Frame(card, bg=COR_CARD)
    frame.pack(padx=20, pady=20, fill=X)
    Label(frame, text="Utilizador:", font=("Segoe UI", 11, "bold"),
          bg=COR_CARD, fg=COR_TEXTO).grid(row=0, column=0, sticky=W, padx=5, pady=8)
    e_user = Entry(frame, font=("Segoe UI", 12), width=22, bd=1, relief=SOLID)
    e_user.grid(row=0, column=1, padx=5, pady=8, ipady=6)
    e_user.focus()
    Label(frame, text="Senha:", font=("Segoe UI", 11, "bold"),
          bg=COR_CARD, fg=COR_TEXTO).grid(row=1, column=0, sticky=W, padx=5, pady=8)
    e_pass = Entry(frame, font=("Segoe UI", 12), width=22, bd=1,
                    relief=SOLID, show="*")
    e_pass.grid(row=1, column=1, padx=5, pady=8, ipady=6)
    msg_var = StringVar()
    Label(auth, textvariable=msg_var, font=("Segoe UI", 10),
          bg=COR_FUNDO, fg=COR_PERIGO).pack(pady=5)
    def confirmar_auth(event=None):
        u = e_user.get().strip()
        p = e_pass.get()
        if not u or not p:
            msg_var.set("Preencha utilizador e senha")
            return
        try:
            from database import autenticar
            sucesso, dados = autenticar(u, p)
            if sucesso and dados["perfil"] in ("admin", "gerente"):
                resultado["ok"] = True
                resultado["nome"] = dados["nome"]
                auth.destroy()
            elif sucesso:
                msg_var.set("Utilizador nao e gerente ou admin")
                e_pass.delete(0, END)
            else:
                msg_var.set("Credenciais invalidas")
                e_pass.delete(0, END)
        except Exception as e:
            msg_var.set(f"Erro: {e}")
    e_user.bind('<Return>', lambda e: e_pass.focus())
    e_pass.bind('<Return>', confirmar_auth)
    Button(auth, text="Autorizar", font=("Segoe UI", 13, "bold"),
           bg=COR_VERDE, fg="white", width=25, height=2, bd=0, cursor="hand2",
           command=confirmar_auth).pack(pady=20)
    auth.wait_window()
    return resultado["ok"], resultado["nome"]


def entrada_caixa(cx_id, utilizador_logado, parent):
    """Regista uma entrada de caixa (dinheiro que entra)."""
    janela = Toplevel(parent)
    janela.title("Entrada de Caixa")
    janela.geometry("550x600")
    janela.configure(bg=COR_FUNDO)
    janela.transient(parent)
    janela.grab_set()
    janela.update_idletasks()
    x = (janela.winfo_screenwidth() - 550) // 2
    y = (janela.winfo_screenheight() - 600) // 2
    janela.geometry(f"550x600+{x}+{y}")
    header = Frame(janela, bg=COR_VERDE, height=80)
    header.pack(fill=X)
    header.pack_propagate(False)
    Label(header, text="ENTRADA DE CAIXA", font=("Segoe UI", 18, "bold"),
          bg=COR_VERDE, fg="white").pack(pady=(15, 0))
    Label(header, text="Registar entrada de dinheiro",
          font=("Segoe UI", 10, "italic"),
          bg=COR_VERDE, fg="#dcfce7").pack()
    body = Frame(janela, bg=COR_FUNDO)
    body.pack(fill=BOTH, expand=True, padx=30, pady=20)
    Label(body, text="Valor (Kz):", font=("Segoe UI", 12, "bold"),
          bg=COR_FUNDO, fg=COR_TEXTO).pack(anchor=W, pady=(10, 5))
    entry_valor = Entry(body, font=("Segoe UI", 16), width=20,
                         justify=CENTER, bd=2, relief=SOLID)
    entry_valor.pack(pady=5, ipady=8)
    entry_valor.focus()
    Label(body, text="Categoria:", font=("Segoe UI", 12, "bold"),
          bg=COR_FUNDO, fg=COR_TEXTO).pack(anchor=W, pady=(15, 5))
    CATEGORIAS_ENTRADA = ["Aporte do gerente", "Devolucao de fornecedor",
                          "Troco extra", "Venda externa", "Outro"]
    categoria_var = StringVar(value=CATEGORIAS_ENTRADA[0])
    combo_cat = ttk.Combobox(body, textvariable=categoria_var,
                                values=CATEGORIAS_ENTRADA, state="readonly",
                                font=("Segoe UI", 11), width=40)
    combo_cat.pack(pady=5, ipady=4)
    Label(body, text="Motivo / Descricao: (obrigatorio)",
          font=("Segoe UI", 12, "bold"),
          bg=COR_FUNDO, fg=COR_TEXTO).pack(anchor=W, pady=(15, 5))
    entry_desc = Entry(body, font=("Segoe UI", 11), width=45,
                        bd=2, relief=SOLID)
    entry_desc.pack(pady=5, ipady=6)
    def confirmar():
        try:
            valor_txt = entry_valor.get().replace(".", "").replace(",", ".")
            valor = float(valor_txt)
            if valor <= 0:
                messagebox.showwarning("Aviso", "O valor deve ser positivo.")
                return
            descricao = entry_desc.get().strip()
            if not descricao:
                messagebox.showwarning("Aviso", "Escreva o motivo da entrada.")
                return
            categoria = categoria_var.get()
            texto_desc = f"[{categoria}] {descricao}"
            registar_movimento_caixa(cx_id, "ENTRADA", valor, texto_desc,
                                       utilizador_logado["id"], utilizador_logado["nome"])
            registar_auditoria(utilizador_logado["id"], utilizador_logado["nome"],
                                "ENTRADA CAIXA",
                                f"Caixa #{cx_id} | {formatar_kz(valor)} | {categoria} | {descricao}")
            messagebox.showinfo("Sucesso",
                f"Entrada registada!\\n\\nValor: {formatar_kz(valor)}\\n"
                f"Categoria: {categoria}\\nDescricao: {descricao}")
            janela.destroy()
            parent.destroy()
            abrir_caixa_menu(utilizador_logado)
        except ValueError:
            messagebox.showerror("Erro", "Digite um valor valido.")
    entry_valor.bind('<Return>', lambda e: entry_desc.focus())
    entry_desc.bind('<Return>', lambda e: confirmar())
    frame_btn = Frame(body, bg=COR_FUNDO)
    frame_btn.pack(pady=25)
    Button(frame_btn, text="Confirmar Entrada", font=("Segoe UI", 13, "bold"),
           bg=COR_VERDE, fg="white", width=20, height=2, bd=0, cursor="hand2",
           command=confirmar).pack(side=LEFT, padx=5)
    Button(frame_btn, text="Cancelar", font=("Segoe UI", 11),
           bg="#6b7280", fg="white", width=15, height=2, bd=0, cursor="hand2",
           command=janela.destroy).pack(side=LEFT, padx=5)
'''

# Substituir função sangria (regex)
padrao_sangria = re.compile(r"def sangria\(cx_id, utilizador_logado, parent\):.*?(?=\ndef )", re.DOTALL)
if "def sangria" in conteudo:
    conteudo = padrao_sangria.sub(nova_saida + "\n\n", conteudo, count=1)
    print("OK: sangria → saida_caixa + entrada_caixa + auth")

# Remover função reforco antiga (se ainda existir)
padrao_reforco = re.compile(r"def reforco\(cx_id, utilizador_logado, parent\):.*?(?=\ndef )", re.DOTALL)
if "def reforco" in conteudo:
    conteudo = padrao_reforco.sub("", conteudo, count=1)
    print("OK: reforco antigo removido")

with open(path, "w", encoding="utf-8") as f:
    f.write(conteudo)

print("OK - caixa.py actualizado")