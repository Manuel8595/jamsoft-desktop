from database import conectar

conn = conectar()
cur = conn.cursor()

print("=" * 60)
print("REGISTOS PENDENTES NA FILA")
print("=" * 60)
cur.execute("SELECT id, uuid, tipo, registo_id, estado, ultimo_erro FROM fila_sincronizacao WHERE estado = 'PENDENTE'")
rows = cur.fetchall()
if rows:
    for r in rows:
        print(f"id={r[0]}")
        print(f"  uuid={r[1]}")
        print(f"  tipo={r[2]}")
        print(f"  registo_id={r[3]}")
        print(f"  estado={r[4]}")
        print(f"  erro={r[5]}")
else:
    print("(nenhum pendente)")

print()
print("=" * 60)
print("ULTIMOS 10 REGISTOS DE QUALQUER ESTADO")
print("=" * 60)
cur.execute("SELECT id, tipo, registo_id, estado, ultimo_erro FROM fila_sincronizacao ORDER BY id DESC LIMIT 10")
for r in cur.fetchall():
    err = (r[4] or "")[:80]
    print(f"id={r[0]} | {r[1]} | reg={r[2]} | {r[3]} | {err}")

conn.close()