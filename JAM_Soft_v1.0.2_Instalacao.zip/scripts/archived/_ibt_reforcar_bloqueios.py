"""
Reforca as 3 funcoes criticas com bloqueios anti-fraude.
Usa padroes EXACTOS do ficheiro actual.
Uso: python _ibt_reforcar_bloqueios.py
"""

path = "transferencias.py"

with open(path, encoding="utf-8") as f:
    c = f.read()

# ============================================================
# 1. ENVIAR - reforcar
# ============================================================
antigo_1 = '''    if r[0] != ESTADO_RASCUNHO:
        conn.close()
        return False, f"Estado actual ({r[0]}) nao permite envio."'''

novo_1 = '''    if r[0] != ESTADO_RASCUNHO:
        conn.close()
        return False, (f"BLOQUEADO: Estado actual ({r[0]}) nao permite envio.\\n\\n"
                        "Apenas RASCUNHOS podem ser enviados.")'''

if antigo_1 in c:
    c = c.replace(antigo_1, novo_1, 1)
    print("OK - enviar_transferencia reforcada")
else:
    print("AVISO - enviar: padrao nao encontrado")

# ============================================================
# 2. RECEBER - reforcar
# ============================================================
antigo_2 = '''    if not r or r[0] != ESTADO_EM_TRANSITO:
        conn.close()
        return False, "Estado actual nao permite recepcao."'''

novo_2 = '''    if not r:
        conn.close()
        return False, "Transferencia nao encontrada."

    if r[0] != ESTADO_EM_TRANSITO:
        conn.close()
        return False, (f"BLOQUEADO: Estado actual ({r[0]}) nao permite recepcao.\\n\\n"
                        "Apenas IBTs EM TRANSITO podem ser recebidas.")'''

if antigo_2 in c:
    c = c.replace(antigo_2, novo_2, 1)
    print("OK - receber_transferencia reforcada")
else:
    print("AVISO - receber: padrao nao encontrado")

# ============================================================
# 3. CANCELAR - reforcar
# ============================================================
antigo_3 = '''    if not r:
        conn.close()
        return False, "Nao encontrada."

    estado = r[0]'''

novo_3 = '''    if not r:
        conn.close()
        return False, "Nao encontrada."

    estado = r[0]

    # BLOQUEIO ANTI-FRAUDE
    if estado in (ESTADO_CONCLUIDA, ESTADO_CANCELADA):
        conn.close()
        return False, (f"BLOQUEADO: IBT {estado} nao pode ser cancelada.\\n\\n"
                        "Apenas RASCUNHOS e EM_TRANSITO podem ser cancelados.")'''

if antigo_3 in c:
    c = c.replace(antigo_3, novo_3, 1)
    print("OK - cancelar_transferencia reforcada")
else:
    print("AVISO - cancelar: padrao nao encontrado")

# ============================================================
# Gravar
# ============================================================
with open(path, "w", encoding="utf-8") as f:
    f.write(c)

print()
print("=" * 60)
print("OK - Bloqueios anti-fraude reforcados!")
print("=" * 60)