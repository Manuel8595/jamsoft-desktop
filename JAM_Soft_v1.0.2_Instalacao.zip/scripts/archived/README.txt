Scripts de desenvolvimento antigos preservados para consulta.
Não execute estes ficheiros para iniciar ou reparar a aplicação.
Os scripts activos do JAM Soft encontram-se na pasta principal.
