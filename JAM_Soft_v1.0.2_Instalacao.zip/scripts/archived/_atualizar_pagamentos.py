import sqlite3

conn = sqlite3.connect('farmacia.db')
cur = conn.cursor()

print("ANTES:")
cur.execute("SELECT forma_pagamento, COUNT(*) FROM vendas GROUP BY forma_pagamento")
for r in cur.fetchall():
    print(f"  {r[0]}: {r[1]} vendas")
print()

# 1. Dinheiro (Kz) -> Dinheiro
cur.execute("UPDATE vendas SET forma_pagamento = 'Dinheiro' WHERE forma_pagamento = 'Dinheiro (Kz)'")
print(f"1. 'Dinheiro (Kz)' -> 'Dinheiro': {cur.rowcount} vendas")

# 2. PIX / Transferencia -> Transferencia
cur.execute("UPDATE vendas SET forma_pagamento = 'Transferencia' WHERE forma_pagamento = 'PIX / Transferencia'")
print(f"2. 'PIX / Transferencia' -> 'Transferencia': {cur.rowcount} vendas")

conn.commit()
print()
print("DEPOIS:")
cur.execute("SELECT forma_pagamento, COUNT(*) FROM vendas GROUP BY forma_pagamento")
for r in cur.fetchall():
    print(f"  {r[0]}: {r[1]} vendas")

conn.close()
print()
print("OK - Vendas atualizadas!")