"""
Descarrega a lista de farmacias do Supabase para a BD local.
Uso: python _sincronizar_farmacias.py
"""

import requests
from database import conectar


def sincronizar_farmacias():
    """Vai buscar as farmacias do Supabase e guarda localmente."""

    try:
        from config_cloud import (SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY,
                                    SYNC_TIMEOUT)
    except ImportError:
        print("ERRO: config_cloud.py nao encontrado")
        return

    headers = {
        "apikey": SUPABASE_PUBLISHABLE_KEY,
        "Authorization": f"Bearer {SUPABASE_PUBLISHABLE_KEY}",
    }

    # Buscar farmacias
    url = f"{SUPABASE_URL}/rest/v1/farmacias?select=*&order=nome"
    print(f"A buscar farmacias do Supabase...")

    try:
        r = requests.get(url, headers=headers, timeout=SYNC_TIMEOUT)
    except Exception as e:
        print(f"ERRO de ligacao: {e}")
        return

    if r.status_code != 200:
        print(f"ERRO HTTP {r.status_code}: {r.text[:200]}")
        return

    farmacias = r.json()
    print(f"OK - {len(farmacias)} farmacias recebidas do Supabase\n")

    conn = conectar()
    cur = conn.cursor()

    importados = 0
    atualizados = 0
    erros = 0

    for f in farmacias:
        try:
            codigo = f.get("codigo")
            nome = f.get("nome")

            if not codigo or not nome:
                continue

            # Verificar se ja existe localmente
            cur.execute("SELECT id FROM farmacias WHERE codigo = ?", (codigo,))
            existe = cur.fetchone()

            ativo = f.get("activo") or f.get("ativo") or True
            ativo_int = 1 if ativo else 0

            if existe:
                # Actualizar
                cur.execute("""
                    UPDATE farmacias
                    SET nome = ?, nif = ?, endereco = ?,
                        telefone = ?, email = ?, responsavel = ?,
                        notas = ?, uuid = ?, activo = ?
                    WHERE codigo = ?
                """, (
                    nome,
                    f.get("nif"),
                    f.get("endereco"),
                    f.get("telefone"),
                    f.get("email"),
                    f.get("responsavel"),
                    f.get("notas"),
                    f.get("uuid"),
                    ativo_int,
                    codigo
                ))
                atualizados += 1
                print(f"  🔄 Actualizada: {nome} ({codigo})")
            else:
                # Inserir nova
                cur.execute("""
                    INSERT INTO farmacias
                    (uuid, codigo, nome, nif, endereco, telefone,
                     email, responsavel, notas, activo, criado_em, sincronizado)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
                """, (
                    f.get("uuid"),
                    codigo,
                    nome,
                    f.get("nif"),
                    f.get("endereco"),
                    f.get("telefone"),
                    f.get("email"),
                    f.get("responsavel"),
                    f.get("notas"),
                    ativo_int,
                    f.get("criado_em", "")
                ))
                importados += 1
                print(f"  ✅ Nova: {nome} ({codigo})")
        except Exception as e:
            erros += 1
            print(f"  ❌ Erro em {f.get('codigo')}: {e}")

    conn.commit()

    # Verificar resultado final
    cur.execute("SELECT COUNT(*) FROM farmacias WHERE activo = 1")
    total_local = cur.fetchone()[0]
    conn.close()

    print()
    print("=" * 60)
    print(f"Importadas:  {importados}")
    print(f"Actualizadas:{atualizados}")
    print(f"Erros:       {erros}")
    print(f"Total local: {total_local} farmacias activas")
    print("=" * 60)


if __name__ == "__main__":
    sincronizar_farmacias()