path = "caixa.py"

with open(path, encoding="utf-8") as f:
    conteudo = f.read()

# Se o ficheiro tiver poucas linhas mas muito caracteres, o \n foi substituido
# Vamos restaurar: substituir o padrão \\n por quebra REAL

# Cuidado: precisamos distinguir "\\n" DENTRO de strings (manter) de "\\n" FORA (restaurar)

# Estratégia: substituir TODOS os \\n por quebra real
conteudo = conteudo.replace("\\n", "\n")

with open(path, "w", encoding="utf-8") as f:
    f.write(conteudo)

print("OK - quebras de linha restauradas")