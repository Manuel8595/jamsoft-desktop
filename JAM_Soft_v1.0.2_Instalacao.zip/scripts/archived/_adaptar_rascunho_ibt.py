"""
Adapta o transferencias.py para suportar RASCUNHOS.
Uso: python _adaptar_rascunho_ibt.py
"""

path = "transferencias.py"

with open(path, encoding="utf-8") as f:
    c = f.read()

# 1. Alterar assinatura do abrir_nova_ibt
antigo = '''def abrir_nova_ibt(utilizador, parent, callback=None):
    """Abre a janela de criacao de nova IBT."""
    janela = Toplevel(parent)
    janela.title("Nova Transferencia (IBT)")
    janela.geometry("1000x850")'''

novo = '''def abrir_nova_ibt(utilizador, parent, callback=None, trans_id_existente=None):
    """Abre a janela de criacao de nova IBT.
    Se trans_id_existente for dado, carrega o rascunho para continuar.
    """
    janela = Toplevel(parent)
    if trans_id_existente:
        janela.title("Continuar Transferencia (IBT)")
    else:
        janela.title("Nova Transferencia (IBT)")
    janela.geometry("1000x850")'''

if antigo in c:
    c = c.replace(antigo, novo)
    print("OK - assinatura abrir_nova_ibt alterada")
else:
    print("AVISO - assinatura nao encontrada")

# 2. Adicionar carregamento do rascunho depois de "carrinho = []"
antigo_carr = '''    carrinho = []

    # Farmacias'''

novo_carr = '''    carrinho = []

    # Se estamos a continuar um rascunho, carregar dados
    if trans_id_existente:
        try:
            itens_rasc = listar_itens_transferencia(trans_id_existente)
            for it in itens_rasc:
                (iid, pid, nome, cod, qtd_env, qtd_rec, dif,
                 lote, val, custo, sub, just) = it
                carrinho.append({
                    "produto_id": pid,
                    "nome": nome,
                    "codigo": cod or "",
                    "qtd": qtd_env,
                    "custo": custo or 0,
                    "subtotal": sub or 0,
                })
        except Exception as e:
            print(f"[IBT] Erro a carregar rascunho: {e}")

    # Farmacias'''

if antigo_carr in c:
    c = c.replace(antigo_carr, novo_carr)
    print("OK - carregamento do rascunho adicionado")
else:
    print("AVISO - bloco 'carrinho = []' nao encontrado")

with open(path, "w", encoding="utf-8") as f:
    f.write(c)

print()
print("=" * 60)
print("OK - transferencias.py adaptado para rascunhos!")
print("=" * 60)