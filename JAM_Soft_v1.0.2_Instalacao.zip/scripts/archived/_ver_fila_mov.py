from database import conectar
import fila_sync

conn = conectar()
cur = conn.cursor()

print("=" * 60)
print("FILA - MOVIMENTOS")
print("=" * 60)
cur.execute("SELECT id, tipo, registo_id, estado FROM fila_sincronizacao WHERE tipo = 'MOVIMENTO' ORDER BY id DESC LIMIT 10")
rows = cur.fetchall()
if rows:
    for r in rows:
        print(f"fila_id={r[0]} | tipo={r[1]} | reg={r[2]} | estado={r[3]}")
else:
    print("(Nenhum movimento na fila)")

print()
print("=" * 60)
print("TOTAL DE PENDENTES")
print("=" * 60)
pend = fila_sync.listar_pendentes(30)
if pend:
    for p in pend:
        print(f"id={p[0]} | tipo={p[2]} | reg={p[4]} | estado={p[6]}")
else:
    print("(Nenhum pendente)")

conn.close()