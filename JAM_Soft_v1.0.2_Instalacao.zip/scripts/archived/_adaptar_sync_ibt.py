"""
Adapta o sincronizacao.py para incluir as 3 tabelas IBT.
Uso: python _adaptar_sync_ibt.py
"""

path = "sincronizacao.py"

with open(path, encoding="utf-8") as f:
    c = f.read()

# ============================================================
# 1. Adicionar ao MAPA_TABELAS
# ============================================================
antigo = '''    "LOG_AUDITORIA": "auditoria",
    "ITEN_COMPRA": "itens_compra",
}'''

novo = '''    "LOG_AUDITORIA": "auditoria",
    "ITEN_COMPRA": "itens_compra",
    "IBT": "transferencias_filiais",
    "ITEN_IBT": "itens_transferencia",
    "HISTORICO_IBT": "historico_ibt",
}'''

if antigo in c and '"IBT": "transferencias_filiais"' not in c:
    c = c.replace(antigo, novo)
    print("OK - MAPA_TABELAS actualizado")
elif '"IBT": "transferencias_filiais"' in c:
    print("OK - MAPA_TABELAS ja tem IBT")
else:
    print("AVISO - MAPA_TABELAS nao encontrado")

# ============================================================
# 2. Adicionar ao _alimentar_fila
# ============================================================
antigo = '''        ("auditoria", "LOG_AUDITORIA"),
        ("itens_compra", "ITEN_COMPRA"),
    ]'''

novo = '''        ("auditoria", "LOG_AUDITORIA"),
        ("itens_compra", "ITEN_COMPRA"),
        ("transferencias_filiais", "IBT"),
        ("itens_transferencia", "ITEN_IBT"),
        ("historico_ibt", "HISTORICO_IBT"),
    ]'''

if antigo in c and '("transferencias_filiais", "IBT")' not in c:
    c = c.replace(antigo, novo)
    print("OK - _alimentar_fila actualizado")
elif '("transferencias_filiais", "IBT")' in c:
    print("OK - _alimentar_fila ja tem IBT")
else:
    print("AVISO - _alimentar_fila nao encontrado")

# ============================================================
# 3. Adicionar contadores no sincronizar_tudo
# ============================================================
antigo = '''        "LOG_AUDITORIA": "logs_auditoria",
        "ITEN_COMPRA": "itens_compra",
    }'''

novo = '''        "LOG_AUDITORIA": "logs_auditoria",
        "ITEN_COMPRA": "itens_compra",
        "IBT": "transf_ibt",
        "ITEN_IBT": "transf_itens",
        "HISTORICO_IBT": "transf_hist",
    }'''

if antigo in c and '"IBT": "transf_ibt"' not in c:
    c = c.replace(antigo, novo)
    print("OK - contadores actualizados")
elif '"IBT": "transf_ibt"' in c:
    print("OK - contadores ja tem IBT")
else:
    print("AVISO - contadores nao encontrados")

# ============================================================
# 4. Adicionar resultado no dicionario inicial
# ============================================================
antigo = '''        "itens_compra": 0,
        "total": 0, "erros": 0, "farmacia_id": None,'''

novo = '''        "itens_compra": 0,
        "transf_ibt": 0, "transf_itens": 0, "transf_hist": 0,
        "total": 0, "erros": 0, "farmacia_id": None,'''

if antigo in c and '"transf_ibt": 0' not in c:
    c = c.replace(antigo, novo)
    print("OK - resultado inicial actualizado")
elif '"transf_ibt": 0' in c:
    print("OK - resultado ja tem IBT")
else:
    print("AVISO - resultado nao encontrado")

# ============================================================
# 5. Adicionar _preparar_payload para IBT
# ============================================================
marcador = '''    # ============ CATEGORIA ============
    elif tipo == "CATEGORIA":'''

novo_payload = '''    # ============ IBT (TRANSFERENCIA) ============
    elif tipo == "IBT":
        cur.execute("""
            SELECT uuid, referencia, data_criacao, data_envio, data_recepcao,
                   farmacia_origem_id, farmacia_origem_codigo, farmacia_origem_nome,
                   farmacia_destino_id, farmacia_destino_codigo, farmacia_destino_nome,
                   utilizador_criou_nome, autorizado_por,
                   estado, total_itens, total_quantidade, valor_estimado,
                   observacoes, terminal_id
            FROM transferencias_filiais WHERE id = ?
        """, (registo_id,))
        r = cur.fetchone()
        if r:
            payload = {
                "uuid": r[0],
                "farmacia_id": farmacia_id,
                "referencia": r[1],
                "data_criacao": r[2],
                "data_envio": r[3],
                "data_recepcao": r[4],
                "farmacia_origem_id": r[5],
                "farmacia_origem_codigo": r[6],
                "farmacia_origem_nome": r[7],
                "farmacia_destino_id": r[8],
                "farmacia_destino_codigo": r[9],
                "farmacia_destino_nome": r[10],
                "utilizador_criou_nome": r[11],
                "autorizado_por": r[12],
                "estado": r[13],
                "total_itens": r[14],
                "total_quantidade": r[15],
                "valor_estimado": r[16],
                "observacoes": r[17],
                "terminal_id": r[18],
            }

    # ============ ITEM DE IBT ============
    elif tipo == "ITEN_IBT":
        cur.execute("""
            SELECT it.id, t.uuid AS transf_uuid, t.referencia,
                   it.produto_id, it.produto_nome, it.codigo_barras,
                   it.quantidade_enviada, it.quantidade_recebida, it.diferenca,
                   it.lote, it.validade, it.preco_custo, it.subtotal, it.justificacao
            FROM itens_transferencia it
            LEFT JOIN transferencias_filiais t ON t.id = it.transferencia_id
            WHERE it.id = ?
        """, (registo_id,))
        r = cur.fetchone()
        if r:
            payload = {
                "farmacia_id": farmacia_id,
                "transferencia_uuid": r[1],
                "transferencia_referencia": r[2],
                "produto_id": r[3],
                "produto_nome": r[4],
                "codigo_barras": r[5],
                "quantidade_enviada": r[6],
                "quantidade_recebida": r[7],
                "diferenca": r[8],
                "lote": r[9],
                "validade": r[10],
                "preco_custo": r[11],
                "subtotal": r[12],
                "justificacao": r[13],
            }

    # ============ HISTORICO IBT ============
    elif tipo == "HISTORICO_IBT":
        cur.execute("""
            SELECT h.id, t.uuid AS transf_uuid,
                   h.data, h.acao, h.utilizador_nome,
                   h.estado_anterior, h.estado_novo, h.detalhes
            FROM historico_ibt h
            LEFT JOIN transferencias_filiais t ON t.id = h.transferencia_id
            WHERE h.id = ?
        """, (registo_id,))
        r = cur.fetchone()
        if r:
            payload = {
                "farmacia_id": farmacia_id,
                "transferencia_uuid": r[1],
                "data": r[2],
                "acao": r[3],
                "utilizador_nome": r[4],
                "estado_anterior": r[5],
                "estado_novo": r[6],
                "detalhes": r[7],
            }

    # ============ CATEGORIA ============
    elif tipo == "CATEGORIA":'''

if marcador in c and '# ============ IBT (TRANSFERENCIA) ============' not in c:
    c = c.replace(marcador, novo_payload)
    print("OK - _preparar_payload IBT adicionado")
elif '# ============ IBT (TRANSFERENCIA) ============' in c:
    print("OK - _preparar_payload IBT ja existe")
else:
    print("AVISO - marcador CATEGORIA nao encontrado")

# ============================================================
# Gravar
# ============================================================
with open(path, "w", encoding="utf-8") as f:
    f.write(c)

print()
print("=" * 60)
print("OK - sincronizacao.py adaptado para IBT!")
print("=" * 60)