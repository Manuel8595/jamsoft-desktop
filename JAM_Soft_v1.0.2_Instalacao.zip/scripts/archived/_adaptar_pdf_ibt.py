"""
Adiciona botao "Gerar PDF" no ecra de Detalhes da IBT.
Uso: python _adaptar_pdf_ibt.py
"""

path = "transferencias.py"

with open(path, encoding="utf-8") as f:
    c = f.read()

# Adicionar botao PDF antes do botao "Fechar" no abrir_detalhes_ibt
antigo = '''    Button(janela, text="❌ Fechar",
           font=("Segoe UI", 11),
           bg="#64748b", fg="white",
           width=15, height=2, bd=0, cursor="hand2",
           command=janela.destroy).pack(pady=10)


# ============================================================
# ============ JANELA: RECEBER IBT ==========================='''

novo = '''    def gerar_pdf():
        try:
            from relatorio_ibt import abrir_escolha_impressao_ibt
            abrir_escolha_impressao_ibt(trans_id, parent=janela)
        except Exception as e:
            messagebox.showerror("Erro", f"Erro ao gerar PDF: {e}")

    frame_btn = Frame(janela, bg=COR_FUNDO)
    frame_btn.pack(pady=10)

    Button(frame_btn, text="🖨️ Gerar PDF",
           font=("Segoe UI", 11, "bold"),
           bg=COR_AZUL, fg="white",
           width=18, height=2, bd=0, cursor="hand2",
           command=gerar_pdf).pack(side=LEFT, padx=5)

    Button(frame_btn, text="❌ Fechar",
           font=("Segoe UI", 11),
           bg="#64748b", fg="white",
           width=15, height=2, bd=0, cursor="hand2",
           command=janela.destroy).pack(side=LEFT, padx=5)


# ============================================================
# ============ JANELA: RECEBER IBT ==========================='''

if antigo in c:
    c = c.replace(antigo, novo)
    print("OK - botao PDF adicionado no abrir_detalhes_ibt")
elif 'text="🖨️ Gerar PDF"' in c:
    print("OK - botao PDF ja existe")
else:
    print("AVISO - padrao nao encontrado")
    print("        Adiciona manualmente no abrir_detalhes_ibt")

with open(path, "w", encoding="utf-8") as f:
    f.write(c)

print()
print("=" * 60)
print("OK - transferencias.py adaptado com botao PDF!")
print("=" * 60)