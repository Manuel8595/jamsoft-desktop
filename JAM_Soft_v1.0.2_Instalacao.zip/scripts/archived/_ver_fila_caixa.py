from database import conectar

conn = conectar()
cur = conn.cursor()

print("=" * 60)
print("FILA - CAIXAS")
print("=" * 60)
cur.execute("SELECT id, tipo, registo_id, estado FROM fila_sincronizacao WHERE tipo = 'CAIXA' ORDER BY id DESC LIMIT 10")
rows = cur.fetchall()
if rows:
    for r in rows:
        print(f"fila_id={r[0]} | tipo={r[1]} | reg={r[2]} | estado={r[3]}")
else:
    print("(Nenhum caixa na fila)")

print()
print("=" * 60)
print("CAIXAS LOCAIS")
print("=" * 60)
cur.execute("SELECT id, uuid, sincronizado FROM caixas")
for r in cur.fetchall():
    print(f"id={r[0]} | uuid={r[1][:20]}... | sinc={r[2]}")

conn.close()