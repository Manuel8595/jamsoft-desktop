from database import conectar
import fila_sync

conn = conectar()
cur = conn.cursor()

# Buscar o lote L001
cur.execute("SELECT id, uuid, sincronizado FROM lotes WHERE id = 1")
r = cur.fetchone()

if not r:
    print("ERRO: lote 1 nao encontrado")
else:
    lote_id, uuid_lote, sinc = r
    print(f"Lote: id={lote_id} uuid={uuid_lote} sinc={sinc}")

    if not uuid_lote:
        print("ERRO: lote sem uuid!")
    else:
        # Tentar adicionar a fila manualmente
        resultado = fila_sync.adicionar_a_fila(uuid_lote, "LOTE", "lotes", lote_id, {})
        print(f"Adicionado a fila: {resultado}")

        if resultado:
            print("OK - vai agora correr F9")
        else:
            print("ERRO - ja existe na fila ou falha")

conn.close()