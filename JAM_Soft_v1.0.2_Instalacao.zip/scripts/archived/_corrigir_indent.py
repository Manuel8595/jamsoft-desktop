import re

path = "pdv.py"
with open(path, encoding="utf-8") as f:
    linhas = f.readlines()

# Encontrar a linha do def concluir
inicio = None
for i, l in enumerate(linhas):
    if "def concluir(forma, total, cliente_id, dinheiro=None, ref=None, sub_o=None, desc=0):" in l:
        inicio = i
        break

if inicio is None:
    print("ERRO: nao encontrei a funcao concluir")
    exit(1)

# Encontrar o fim (proxima linha com 'def ' ao mesmo nivel OU fim do ficheiro)
fim = None
for i in range(inicio + 1, len(linhas)):
    # Se encontrar uma linha com def (sem espacos a mais) -> fim
    if re.match(r"^    def ", linhas[i]):
        fim = i
        break
    # Se encontrar linha que nao tem indentacao nenhuma (comentario global) -> fim
    if linhas[i].strip() and not linhas[i].startswith(" "):
        fim = i
        break

if fim is None:
    fim = len(linhas)

print(f"Funcao concluir: linhas {inicio+1} a {fim}")

# Corrigir a indentacao: adicionar 4 espacos a todas as linhas DEPOIS da def
for i in range(inicio + 1, fim):
    l = linhas[i]
    if l.strip():  # ignorar linhas vazias
        linhas[i] = "    " + l

with open(path, "w", encoding="utf-8") as f:
    f.writelines(linhas)

print("OK - indentacao corrigida")