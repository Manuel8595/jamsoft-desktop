"""
Corrige o bloco dos botoes que ficou FORA da funcao abrir_lista_ibt.
Move-o para dentro da funcao.
Uso: python _fix_final_botoes_ibt.py
"""

path = "transferencias.py"

with open(path, encoding="utf-8") as f:
    linhas = f.readlines()

# ============================================================
# 1. Encontrar as linhas exactas
# ============================================================

# Encontrar o bloco dos botoes mal colocado
idx_inicio_bloco = None
idx_fim_bloco = None

for i, l in enumerate(linhas):
    if "BARRA DE BOTOES FIXA EM BAIXO" in l:
        # Verificar que este bloco esta DEPOIS do comentario "JANELA: DETALHES IBT"
        for j in range(max(0, i - 10), i):
            if "JANELA: DETALHES IBT" in linhas[j]:
                idx_inicio_bloco = i - 1  # linha antes do comentario "==="
                break
        if idx_inicio_bloco:
            break

if idx_inicio_bloco is None:
    print("ERRO - nao encontrei o bloco mal colocado")
    exit()

print(f"OK - bloco mal colocado comeca na linha {idx_inicio_bloco + 1}")

# Encontrar o fim do bloco (ultimo botao Fechar)
for i in range(idx_inicio_bloco, len(linhas)):
    if 'text="❌ Fechar"' in linhas[i]:
        # Andar ate ao fim do .pack(...)
        j = i
        while j < len(linhas) and not linhas[j].strip().endswith(")"):
            j += 1
        idx_fim_bloco = j
        break

if idx_fim_bloco is None:
    print("ERRO - nao encontrei o fim do bloco")
    exit()

print(f"OK - bloco mal colocado acaba na linha {idx_fim_bloco + 1}")

# ============================================================
# 2. Guardar o bloco mal colocado
# ============================================================
bloco_botoes = linhas[idx_inicio_bloco:idx_fim_bloco + 1]

# ============================================================
# 3. Remover o bloco mal colocado
# ============================================================
# Tambem remover o comentario "JANELA: DETALHES IBT" se ficou solto
del linhas[idx_inicio_bloco:idx_fim_bloco + 1]

print("OK - bloco removido do lugar errado")

# ============================================================
# 4. Encontrar onde inserir (dentro da funcao abrir_lista_ibt)
# ============================================================
# O bloco deve ficar ANTES do fim da funcao abrir_lista_ibt
# ou seja, ANTES dos comentarios "# ===...JANELA: DETALHES IBT"

idx_inserir = None
for i, l in enumerate(linhas):
    if "# ============ JANELA: DETALHES IBT" in l:
        # Inserir ANTES da linha "=====" acima deste comentario
        j = i - 1
        while j >= 0 and linhas[j].strip().startswith("#"):
            j -= 1
        idx_inserir = j + 1
        break

if idx_inserir is None:
    print("ERRO - nao encontrei onde inserir")
    exit()

print(f"OK - vou inserir na linha {idx_inserir + 1}")

# ============================================================
# 5. Inserir o bloco no lugar correcto
# ============================================================
# Adicionar linha vazia antes
linhas[idx_inserir:idx_inserir] = ["\n"] + bloco_botoes + ["\n"]

print("OK - bloco inserido no lugar correcto")

# ============================================================
# 6. Gravar
# ============================================================
with open(path, "w", encoding="utf-8") as f:
    f.writelines(linhas)

print()
print("=" * 60)
print("OK - Correcao final aplicada!")
print("=" * 60)