path = "caixa.py"

with open(path, encoding="utf-8") as f:
    c = f.read()

# Corrigir todas as f-strings quebradas (newline real em vez de \n)
c = c.replace('"Nao e possivel fechar!\n\n"', '"Nao e possivel fechar!\\n\\n"')
c = c.replace('"FALTA: " + formatar_kz(abs(diff_cash)) + "\n\n"', 
              '"FALTA: " + formatar_kz(abs(diff_cash)) + "\\n\\n"')
c = c.replace('"Reconte o dinheiro antes de fechar."', 
              '"Reconte o dinheiro antes de fechar."')
c = c.replace('"Ha sobra no caixa.\n\n"', '"Ha sobra no caixa.\\n\\n"')
c = c.replace('"Tem de escrever o motivo."', '"Tem de escrever o motivo."')
c = c.replace('"Fechar o caixa?\n\n"', '"Fechar o caixa?\\n\\n"')
c = c.replace('"Cash: " + formatar_kz(total_cash) + "\n"', 
              '"Cash: " + formatar_kz(total_cash) + "\\n"')
c = c.replace('"TPA:  " + formatar_kz(total_tpa) + " (" + str(num_taloes) + " taloes)\n"',
              '"TPA:  " + formatar_kz(total_tpa) + " (" + str(num_taloes) + " taloes)\\n"')
c = c.replace('"Depositar: " + valor_depositar_var.get()', 
              '"Depositar: " + valor_depositar_var.get()')
c = c.replace('"CAIXA #" + str(cx_id) + " FECHADO!\n\n"',
              '"CAIXA #" + str(cx_id) + " FECHADO!\\n\\n"')
c = c.replace('"Cash: " + formatar_kz(total_cash) + "\n"',
              '"Cash: " + formatar_kz(total_cash) + "\\n"')
c = c.replace('"TPA:  " + formatar_kz(total_tpa) + "\n"',
              '"TPA:  " + formatar_kz(total_tpa) + "\\n"')
c = c.replace('"Depositar: " + valor_depositar_var.get() + "\n"',
              '"Depositar: " + valor_depositar_var.get() + "\\n"')
c = c.replace('"Fundo ao gerente: " + formatar_kz(fundo_inicial) + "\n\n"',
              '"Fundo ao gerente: " + formatar_kz(fundo_inicial) + "\\n\\n"')

with open(path, "w", encoding="utf-8") as f:
    f.write(c)

print("OK - ficheiro corrigido")