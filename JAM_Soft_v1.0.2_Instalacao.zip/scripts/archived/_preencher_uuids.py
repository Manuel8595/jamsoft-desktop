"""
Preenche uuid nos registos antigos das tabelas sincronizaveis.
Uso: python _preencher_uuids.py
"""

import uuid
import os
from database import conectar


TABELAS = [
    # Tabelas antigas (ja sincronizavam)
    "vendas", "compras", "perdas", "movimentos_caixa",
    "itens_venda", "produtos", "lotes", "clientes",
    "facturas", "devolucoes", "turnos_caixa", "dias_operacao",
    "metas_farmacia",
    # Tabelas novas (adicionadas agora)
    "categorias", "fornecedores", "utilizadores",
    "itens_factura", "inventarios", "itens_inventario",
    "depositos", "saldo_farmacia", "nao_conformidades",
    "auditorias_realizadas", "auditoria", "itens_compra",
]


def main():
    conn = conectar()
    cur = conn.cursor()
    terminal = os.environ.get("COMPUTERNAME", "TERM-01")
    total = 0

    for t in TABELAS:
        try:
            cur.execute(f"SELECT id FROM {t} WHERE uuid IS NULL")
            ids = [r[0] for r in cur.fetchall()]

            for rid in ids:
                u = str(uuid.uuid4())
                cur.execute(
                    f"UPDATE {t} SET uuid = ?, terminal_id = ?, sincronizado = 0 WHERE id = ?",
                    (u, terminal, rid)
                )
                total += 1

            print(f"{t:25}: {len(ids):4} registos actualizados")

        except Exception as e:
            print(f"{t:25}: ERRO - {e}")

    conn.commit()
    conn.close()
    print()
    print(f"TOTAL: {total} registos actualizados")


if __name__ == "__main__":
    main()