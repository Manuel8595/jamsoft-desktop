from database import gravar_config_financeira

gravar_config_financeira('timeout_inatividade', '15', 'Manuel')
print("OK - timeout = 15 minutos")

# Confirmar
from database import obter_config_financeira
print("Valor actual:", obter_config_financeira('timeout_inatividade', '15'))