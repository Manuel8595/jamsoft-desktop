from database import conectar

conn = conectar()
cur = conn.cursor()

print("=" * 60)
print("PRODUTOS COM sincronizado=0")
print("=" * 60)
cur.execute("SELECT id, nome, estoque_atual, uuid, sincronizado FROM produtos WHERE sincronizado = 0")
rows = cur.fetchall()
if rows:
    for r in rows:
        print(f"id={r[0]} | {r[1]} | stock={r[2]} | sinc={r[4]}")
else:
    print("(nenhum)")

print()
print("=" * 60)
print("FILA - ULTIMOS 20")
print("=" * 60)
cur.execute("SELECT id, tipo, registo_id, estado FROM fila_sincronizacao ORDER BY id DESC LIMIT 20")
for r in cur.fetchall():
    print(f"fila_id={r[0]} | {r[1]} | reg={r[2]} | {r[3]}")

print()
print("=" * 60)
print("FILA - PRODUTOS (qualquer estado)")
print("=" * 60)
cur.execute("SELECT id, tipo, registo_id, estado, ultimo_erro FROM fila_sincronizacao WHERE tipo = 'PRODUTO' ORDER BY id DESC")
rows = cur.fetchall()
if rows:
    for r in rows:
        err = (r[4] or "")[:80]
        print(f"fila_id={r[0]} | reg={r[2]} | {r[3]} | {err}")
else:
    print("(nenhum produto na fila)")

conn.close()