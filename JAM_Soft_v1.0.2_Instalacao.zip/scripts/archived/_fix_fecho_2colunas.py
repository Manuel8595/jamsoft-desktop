import re

path = "caixa.py"

with open(path, encoding="utf-8") as f:
    c = f.read()

# ─── Nova função fechar_caixa_janela (2 colunas) ───
nova_funcao = '''def fechar_caixa_janela(cx_id, utilizador_logado, parent):
    """Fecho de caixa com contagem de notas + TPA + senha gerente (2 colunas)."""

    from database import conectar, listar_movimentos_caixa

    dados = atualizar_totais_caixa(cx_id)
    esperado_cash = dados["valor_esperado"]
    esperado_tpa = dados.get("total_tpa", 0) or 0
    fundo_inicial = dados["valor_inicial"]

    # Info do caixa
    try:
        conn = conectar()
        cur = conn.cursor()
        cur.execute("""
            SELECT data_abertura, utilizador_abertura_nome,
                   (SELECT COUNT(*) FROM vendas WHERE caixa_id = ?) as num_vendas,
                   (SELECT COALESCE(SUM(total), 0) FROM vendas WHERE caixa_id = ?) as total_vendas
            FROM caixas WHERE id = ?
        """, (cx_id, cx_id, cx_id))
        info_caixa = cur.fetchone()
        conn.close()
    except Exception:
        info_caixa = (None, "-", 0, 0)

    # Movimentos do dia
    try:
        movimentos = listar_movimentos_caixa(cx_id) or []
        movimentos = list(movimentos)[-5:]  # últimos 5
    except Exception:
        movimentos = []

    janela = Toplevel(parent)
    janela.title("Fechar Caixa - Contagem")
    janela.state("zoomed")
    janela.configure(bg=COR_FUNDO)
    janela.transient(parent)
    janela.grab_set()

    # Header
    header = Frame(janela, bg="#be185d", height=60)
    header.pack(fill=X)
    header.pack_propagate(False)
    Label(header, text="FECHO DE CAIXA - CONTAGEM",
          font=("Segoe UI", 16, "bold"),
          bg="#be185d", fg="white").pack(pady=15)

    # Container 2 colunas
    main = Frame(janela, bg=COR_FUNDO)
    main.pack(fill=BOTH, expand=True, padx=15, pady=10)

    col_esq = Frame(main, bg=COR_FUNDO)
    col_esq.pack(side=LEFT, fill=BOTH, expand=True, padx=(0, 8))

    col_dir = Frame(main, bg=COR_FUNDO)
    col_dir.pack(side=RIGHT, fill=BOTH, expand=True, padx=(8, 0))

    # ═══════════════════════════════════════════════════════
    # COLUNA ESQUERDA
    # ═══════════════════════════════════════════════════════

    # RESUMO
    Label(col_esq, text="📊 RESUMO DO SISTEMA",
          font=("Segoe UI", 11, "bold"),
          bg=COR_FUNDO, fg=COR_TEXTO, anchor=W).pack(fill=X)

    card_res = Frame(col_esq, bg=COR_CARD, highlightthickness=1,
                      highlightbackground="#cbd5e1")
    card_res.pack(fill=X, pady=(3, 8))

    def _linha(parent, label, valor, cor=COR_TEXTO):
        f = Frame(parent, bg=COR_CARD)
        f.pack(fill=X, padx=10, pady=1)
        Label(f, text=label, font=("Segoe UI", 9),
              bg=COR_CARD, fg="#64748b").pack(side=LEFT)
        Label(f, text=valor, font=("Segoe UI", 10, "bold"),
              bg=COR_CARD, fg=cor).pack(side=RIGHT)

    _linha(card_res, "Fundo inicial:", formatar_kz(fundo_inicial))
    _linha(card_res, "+ Vendas Dinheiro:",
           formatar_kz(dados["total_vendas"]), COR_VERDE)
    _linha(card_res, "+ Reforços:",
           formatar_kz(dados["total_reforcos"]), COR_VERDE)
    _linha(card_res, "- Sangrias:",
           formatar_kz(dados["total_sangrias"]), COR_PERIGO)
    _linha(card_res, "ESPERADO CASH:",
           formatar_kz(esperado_cash), COR_PRIMARIA)
    _linha(card_res, "ESPERADO TPA:",
           formatar_kz(esperado_tpa), "#0891b2")

    # CONTAGEM DE NOTAS (2 colunas internas)
    Label(col_esq, text="💵 CONTAGEM DE DINHEIRO (CASH)",
          font=("Segoe UI", 11, "bold"),
          bg=COR_FUNDO, fg=COR_TEXTO, anchor=W).pack(fill=X)

    card_notas = Frame(col_esq, bg=COR_CARD, highlightthickness=1,
                        highlightbackground="#cbd5e1")
    card_notas.pack(fill=X, pady=(3, 8))

    # 2 colunas internas
    notas_esq = Frame(card_notas, bg=COR_CARD)
    notas_esq.pack(side=LEFT, fill=BOTH, expand=True, padx=8, pady=8)

    notas_dir = Frame(card_notas, bg=COR_CARD)
    notas_dir.pack(side=RIGHT, fill=BOTH, expand=True, padx=8, pady=8)

    NOTAS_ESQ = [5000, 2000, 1000, 500, 200]
    NOTAS_DIR = [100, 50, 20, 10]

    entries_notas = {}
    total_contado_var = StringVar(value="Kz 0,00")
    diff_cash_var = StringVar(value="—")

    def _atualizar_total_cash(*args):
        total = 0
        for nota, entry in entries_notas.items():
            try:
                qtd = int(entry.get() or 0)
                total += qtd * nota
            except ValueError:
                pass
        total_contado_var.set(formatar_kz(total))

        dif = total - esperado_cash
        if abs(dif) < 0.01:
            diff_cash_var.set("OK")
        elif dif > 0:
            diff_cash_var.set(f"SOBRA: +{formatar_kz(dif)}")
        else:
            diff_cash_var.set(f"FALTA: -{formatar_kz(abs(dif))}")

    def _criar_linha_nota(parent, nota):
        f = Frame(parent, bg=COR_CARD)
        f.pack(fill=X, pady=1)

        Label(f, text=f"Kz {nota:,.0f}".replace(",", "."),
              font=("Segoe UI", 9, "bold"),
              bg=COR_CARD, fg=COR_TEXTO, width=8, anchor=W).pack(side=LEFT)

        e = Entry(f, font=("Segoe UI", 10), width=6,
                   justify=CENTER, bd=1, relief=SOLID)
        e.pack(side=LEFT, padx=3, ipady=2)
        e.insert(0, "0")
        e.bind("<KeyRelease>", _atualizar_total_cash)
        entries_notas[nota] = e

        sub_var = StringVar(value="Kz 0,00")
        Label(f, textvariable=sub_var,
               font=("Segoe UI", 9, "bold"),
               bg=COR_CARD, fg=COR_PRIMARIA,
               width=12, anchor=E).pack(side=RIGHT)

        def _cb(nota_ref, entry_ref, sub_var_ref):
            def _fn(*args):
                try:
                    qtd = int(entry_ref.get() or 0)
                    sub_var_ref.set(formatar_kz(qtd * nota_ref))
                except ValueError:
                    sub_var_ref.set("Kz 0,00")
                _atualizar_total_cash()
            return _fn

        e.bind("<KeyRelease>", _cb(nota, e, sub_var), add="+")

    for n in NOTAS_ESQ:
        _criar_linha_nota(notas_esq, n)
    for n in NOTAS_DIR:
        _criar_linha_nota(notas_dir, n)

    # TOTAL
    total_frame = Frame(card_notas, bg="#f1f5f9")
    total_frame.pack(fill=X, padx=8, pady=(0, 8))

    Label(total_frame, text="TOTAL CASH:",
          font=("Segoe UI", 10, "bold"),
          bg="#f1f5f9", fg=COR_TEXTO).pack(side=LEFT, padx=8, pady=6)
    Label(total_frame, textvariable=total_contado_var,
          font=("Segoe UI", 12, "bold"),
          bg="#f1f5f9", fg=COR_PRIMARIA).pack(side=LEFT)

    Label(total_frame, text="  DIF:",
          font=("Segoe UI", 10, "bold"),
          bg="#f1f5f9", fg=COR_TEXTO).pack(side=LEFT, padx=(15, 3))
    diff_lbl = Label(total_frame, textvariable=diff_cash_var,
                      font=("Segoe UI", 10, "bold"),
                      bg="#f1f5f9", fg=COR_ALERTA)
    diff_lbl.pack(side=LEFT)

    def _colorir(*args):
        t = diff_cash_var.get()
        if "OK" in t:
            diff_lbl.config(fg=COR_VERDE)
        elif "SOBRA" in t:
            diff_lbl.config(fg=COR_ALERTA)
        else:
            diff_lbl.config(fg=COR_PERIGO)

    diff_cash_var.trace("w", _colorir)

    # TPA
    Label(col_esq, text="💳 CONTAGEM TPA (CARTAO)",
          font=("Segoe UI", 11, "bold"),
          bg=COR_FUNDO, fg=COR_TEXTO, anchor=W).pack(fill=X)

    card_tpa = Frame(col_esq, bg=COR_CARD, highlightthickness=1,
                      highlightbackground="#cbd5e1")
    card_tpa.pack(fill=X, pady=(3, 8))

    f1 = Frame(card_tpa, bg=COR_CARD)
    f1.pack(fill=X, padx=10, pady=4)
    Label(f1, text="Nº talões:", font=("Segoe UI", 9, "bold"),
          bg=COR_CARD, fg=COR_TEXTO, width=10, anchor=W).pack(side=LEFT)
    entry_taloes = Entry(f1, font=("Segoe UI", 10), width=6,
                          justify=CENTER, bd=1, relief=SOLID)
    entry_taloes.pack(side=LEFT, padx=5, ipady=2)
    entry_taloes.insert(0, "0")

    Label(f1, text="  Valor:", font=("Segoe UI", 9, "bold"),
          bg=COR_CARD, fg=COR_TEXTO).pack(side=LEFT, padx=(10, 3))
    entry_tpa_valor = Entry(f1, font=("Segoe UI", 10), width=14,
                             justify=CENTER, bd=1, relief=SOLID)
    entry_tpa_valor.pack(side=LEFT, padx=3, ipady=2)

    diff_tpa_var = StringVar(value="—")

    def _calc_diff_tpa(*args):
        try:
            txt = entry_tpa_valor.get().replace(".", "").replace(",", ".")
            valor = float(txt or 0)
            dif = valor - esperado_tpa
            if abs(dif) < 0.01:
                diff_tpa_var.set("OK")
            elif dif > 0:
                diff_tpa_var.set(f"SOBRA: +{formatar_kz(dif)}")
            else:
                diff_tpa_var.set(f"FALTA: -{formatar_kz(abs(dif))}")
        except ValueError:
            diff_tpa_var.set("—")

    entry_tpa_valor.bind("<KeyRelease>", _calc_diff_tpa)

    f2 = Frame(card_tpa, bg=COR_CARD)
    f2.pack(fill=X, padx=10, pady=(0, 8))
    Label(f2, text=f"Esperado: {formatar_kz(esperado_tpa)}",
          font=("Segoe UI", 9), bg=COR_CARD, fg="#64748b").pack(side=LEFT)
    Label(f2, text="  Dif: ", font=("Segoe UI", 9, "bold"),
          bg=COR_CARD, fg=COR_TEXTO).pack(side=LEFT)
    Label(f2, textvariable=diff_tpa_var,
          font=("Segoe UI", 10, "bold"),
          bg=COR_CARD, fg=COR_ALERTA).pack(side=LEFT)

    # DEPOSITO
    Label(col_esq, text="💰 VALOR A DEPOSITAR",
          font=("Segoe UI", 11, "bold"),
          bg=COR_FUNDO, fg=COR_TEXTO, anchor=W).pack(fill=X)

    card_dep = Frame(col_esq, bg="#dcfce7", highlightthickness=1,
                      highlightbackground="#16a34a")
    card_dep.pack(fill=X, pady=(3, 8))

    valor_depositar_var = StringVar(value="Kz 0,00")

    def _calc_dep(*args):
        try:
            txt = total_contado_var.get().replace("Kz", "").replace(".", "").replace(",", ".").strip()
            total = float(txt or 0)
            dep = total - fundo_inicial
            valor_depositar_var.set(formatar_kz(dep) if dep > 0 else "Kz 0,00")
        except ValueError:
            valor_depositar_var.set("Kz 0,00")

    total_contado_var.trace("w", _calc_dep)

    f_dep = Frame(card_dep, bg="#dcfce7")
    f_dep.pack(fill=X, padx=10, pady=6)
    Label(f_dep, text="Total contado - Fundo:",
          font=("Segoe UI", 9), bg="#dcfce7", fg="#166534").pack(side=LEFT)
    Label(f_dep, textvariable=valor_depositar_var,
          font=("Segoe UI", 12, "bold"),
          bg="#dcfce7", fg=COR_VERDE).pack(side=RIGHT)

    # OBSERVAÇÕES
    Label(col_esq, text="📝 OBSERVAÇÕES (obrigatório se SOBRA):",
          font=("Segoe UI", 11, "bold"),
          bg=COR_FUNDO, fg=COR_TEXTO, anchor=W).pack(fill=X)

    entry_obs = Entry(col_esq, font=("Segoe UI", 10),
                       bd=1, relief=SOLID)
    entry_obs.pack(fill=X, pady=3, ipady=5)

    # BOTÕES
    frame_btn = Frame(col_esq, bg=COR_FUNDO)
    frame_btn.pack(fill=X, pady=10)

    # ═══════════════════════════════════════════════════════
    # COLUNA DIREITA
    # ═══════════════════════════════════════════════════════

    Label(col_dir, text="🔵 PAINEL DE VALIDAÇÃO",
          font=("Segoe UI", 11, "bold"),
          bg=COR_FUNDO, fg=COR_TEXTO, anchor=W).pack(fill=X)

    card_val = Frame(col_dir, bg=COR_CARD, highlightthickness=2,
                      highlightbackground=COR_PRIMARIA)
    card_val.pack(fill=X, pady=(3, 10))

    val_cash_var = StringVar(value="Esperando...")
    val_tpa_var = StringVar(value="Esperando...")

    def _atualizar_painel(*args):
        # CASH
        try:
            txt = total_contado_var.get().replace("Kz", "").replace(".", "").replace(",", ".").strip()
            cash = float(txt or 0)
            dif = cash - esperado_cash
            if abs(dif) < 0.01:
                val_cash_var.set(f"🟢 OK     (contado: {formatar_kz(cash)})")
            elif dif > 0:
                val_cash_var.set(f"🟡 SOBRA  +{formatar_kz(dif)}")
            else:
                val_cash_var.set(f"🔴 FALTA  -{formatar_kz(abs(dif))}")
        except Exception:
            val_cash_var.set("Esperando...")

        # TPA
        try:
            txt = entry_tpa_valor.get().replace(".", "").replace(",", ".")
            tpa = float(txt or 0)
            dif = tpa - esperado_tpa
            if abs(dif) < 0.01:
                val_tpa_var.set(f"🟢 OK     (contado: {formatar_kz(tpa)})")
            elif dif > 0:
                val_tpa_var.set(f"🟡 SOBRA  +{formatar_kz(dif)}")
            else:
                val_tpa_var.set(f"🔴 FALTA  -{formatar_kz(abs(dif))}")
        except Exception:
            val_tpa_var.set("Esperando...")

    total_contado_var.trace("w", _atualizar_painel)
    diff_tpa_var.trace("w", _atualizar_painel)

    f_cash = Frame(card_val, bg=COR_CARD)
    f_cash.pack(fill=X, padx=12, pady=(10, 5))
    Label(f_cash, text="💵 CASH:",
          font=("Segoe UI", 11, "bold"),
          bg=COR_CARD, fg=COR_TEXTO).pack(anchor=W)
    Label(f_cash, textvariable=val_cash_var,
          font=("Segoe UI", 12, "bold"),
          bg=COR_CARD, fg=COR_TEXTO).pack(anchor=W, pady=(3, 0))

    f_tpa = Frame(card_val, bg=COR_CARD)
    f_tpa.pack(fill=X, padx=12, pady=(5, 10))
    Label(f_tpa, text="💳 TPA:",
          font=("Segoe UI", 11, "bold"),
          bg=COR_CARD, fg=COR_TEXTO).pack(anchor=W)
    Label(f_tpa, textvariable=val_tpa_var,
          font=("Segoe UI", 12, "bold"),
          bg=COR_CARD, fg=COR_TEXTO).pack(anchor=W, pady=(3, 0))

    # FUNDO AO GERENTE
    Label(col_dir, text="🏦 FUNDO AO GERENTE",
          font=("Segoe UI", 11, "bold"),
          bg=COR_FUNDO, fg=COR_TEXTO, anchor=W).pack(fill=X)

    card_fundo = Frame(col_dir, bg="#fef3c7", highlightthickness=1,
                        highlightbackground="#f59e0b")
    card_fundo.pack(fill=X, pady=(3, 10))
    Label(card_fundo, text=formatar_kz(fundo_inicial),
          font=("Segoe UI", 14, "bold"),
          bg="#fef3c7", fg="#92400e").pack(pady=8)

    # MOVIMENTOS
    Label(col_dir, text=f"📋 MOVIMENTOS DO DIA ({len(movimentos)})",
          font=("Segoe UI", 11, "bold"),
          bg=COR_FUNDO, fg=COR_TEXTO, anchor=W).pack(fill=X)

    card_mov = Frame(col_dir, bg=COR_CARD, highlightthickness=1,
                      highlightbackground="#cbd5e1")
    card_mov.pack(fill=X, pady=(3, 10))

    if movimentos:
        for m in movimentos:
            try:
                data_m, tipo_m, valor_m, desc_m, user_m = m[:5]
                hora = (data_m or "")[-8:] if data_m else "-"
                cor = COR_VERDE if tipo_m in ("ENTRADA", "REFORCO") else COR_PERIGO
                sinal = "+" if tipo_m in ("ENTRADA", "REFORCO") else "-"
                fm = Frame(card_mov, bg=COR_CARD)
                fm.pack(fill=X, padx=10, pady=2)
                Label(fm, text=f"{hora} {tipo_m[:12]}",
                      font=("Segoe UI", 9),
                      bg=COR_CARD, fg=COR_TEXTO).pack(side=LEFT)
                Label(fm, text=f"{sinal}{formatar_kz(abs(valor_m or 0))}",
                      font=("Segoe UI", 9, "bold"),
                      bg=COR_CARD, fg=cor).pack(side=RIGHT)
            except Exception:
                pass
    else:
        Label(card_mov, text="Sem movimentos",
              font=("Segoe UI", 9, "italic"),
              bg=COR_CARD, fg="#94a3b8").pack(pady=8)

    # INFO CAIXA
    Label(col_dir, text="📊 INFO DO CAIXA",
          font=("Segoe UI", 11, "bold"),
          bg=COR_FUNDO, fg=COR_TEXTO, anchor=W).pack(fill=X)

    card_info = Frame(col_dir, bg=COR_CARD, highlightthickness=1,
                       highlightbackground="#cbd5e1")
    card_info.pack(fill=X, pady=(3, 10))

    def _info(parent, label, valor):
        f = Frame(parent, bg=COR_CARD)
        f.pack(fill=X, padx=10, pady=2)
        Label(f, text=label, font=("Segoe UI", 9),
              bg=COR_CARD, fg="#64748b").pack(side=LEFT)
        Label(f, text=str(valor), font=("Segoe UI", 10, "bold"),
              bg=COR_CARD, fg=COR_TEXTO).pack(side=RIGHT)

    _info(card_info, "Caixa:", f"#{cx_id}")
    _info(card_info, "Aberto:", (info_caixa[0] or "-")[:16])
    _info(card_info, "Operador:", info_caixa[1] or "-")
    _info(card_info, "Nº vendas:", info_caixa[2] or 0)
    _info(card_info, "Total vendas:", formatar_kz(info_caixa[3] or 0))

    # ═══════════════════════════════════════════════════════
    # BOTÕES (na coluna esquerda, no fim)
    # ═══════════════════════════════════════════════════════

    def confirmar():
        try:
            txt = total_contado_var.get().replace("Kz", "").replace(".", "").replace(",", ".").strip()
            total_cash = float(txt or 0)
        except ValueError:
            messagebox.showerror("Erro", "Valor contado cash invalido.")
            return

        try:
            tpa_txt = entry_tpa_valor.get().replace(".", "").replace(",", ".")
            total_tpa = float(tpa_txt or 0)
        except ValueError:
            messagebox.showerror("Erro", "Valor TPA invalido.")
            return

        try:
            num_taloes = int(entry_taloes.get() or 0)
        except ValueError:
            num_taloes = 0

        diff_cash = total_cash - esperado_cash
        observacoes = entry_obs.get().strip()

        if diff_cash < -0.01:
            messagebox.showerror("FALTA em Cash",
                "Nao e possivel fechar!\\n\\n"
                "FALTA: " + formatar_kz(abs(diff_cash)) + "\\n\\n"
                "Reconte o dinheiro antes de fechar.")
            return

        if diff_cash > 0.01 and not observacoes:
            messagebox.showwarning("Observação obrigatória",
                "Ha sobra no caixa.\\n\\n"
                "Tem de escrever o motivo.")
            return

        if not messagebox.askyesno("Confirmar Fecho",
            "Fechar o caixa?\\n\\n"
            "Cash: " + formatar_kz(total_cash) + "\\n"
            "TPA:  " + formatar_kz(total_tpa) + " (" + str(num_taloes) + " taloes)\\n"
            "Depositar: " + valor_depositar_var.get()):
            return

        from caixa import _pedir_autorizacao_gerente
        ok, nome_gerente = _pedir_autorizacao_gerente(
            janela,
            "Fecho do caixa #" + str(cx_id),
            utilizador_logado
        )
        if not ok:
            return

        detalhe = {}
        for nota, entry in entries_notas.items():
            try:
                qtd = int(entry.get() or 0)
                if qtd > 0:
                    detalhe[str(nota)] = qtd
            except ValueError:
                pass

        try:
            resultado = fechar_caixa(
                cx_id, utilizador_logado["id"], utilizador_logado["nome"],
                total_cash, observacoes,
                contado_tpa=total_tpa,
                num_taloes_tpa=num_taloes,
                detalhe_notas=detalhe
            )

            registar_auditoria(
                utilizador_logado["id"], utilizador_logado["nome"],
                "FECHO CAIXA",
                "Caixa #" + str(cx_id) + " | Cash: " + formatar_kz(total_cash) + 
                " | TPA: " + formatar_kz(total_tpa) +
                " | Autorizado por: " + nome_gerente
            )

            messagebox.showinfo("Caixa Fechado",
                "CAIXA #" + str(cx_id) + " FECHADO!\\n\\n"
                "Cash: " + formatar_kz(total_cash) + "\\n"
                "TPA:  " + formatar_kz(total_tpa) + "\\n"
                "Depositar: " + valor_depositar_var.get() + "\\n"
                "Fundo ao gerente: " + formatar_kz(fundo_inicial) + "\\n\\n"
                "Autorizado por: " + nome_gerente)

            janela.destroy()
            parent.destroy()
            abrir_caixa_menu(utilizador_logado)

        except Exception as e:
            import traceback
            traceback.print_exc()
            messagebox.showerror("Erro", "Erro ao fechar caixa: " + str(e))

    Button(frame_btn, text="✅ Confirmar Fecho",
           font=("Segoe UI", 12, "bold"),
           bg="#be185d", fg="white",
           width=20, height=2, bd=0, cursor="hand2",
           command=confirmar).pack(side=LEFT, padx=3)

    Button(frame_btn, text="❌ Cancelar",
           font=("Segoe UI", 11),
           bg="#6b7280", fg="white",
           width=15, height=2, bd=0, cursor="hand2",
           command=janela.destroy).pack(side=LEFT, padx=3)'''

# ─── Substituir ───
padrao = re.compile(
    r"def fechar_caixa_janela\(cx_id, utilizador_logado, parent\):.*?(?=\ndef )",
    re.DOTALL
)

if "def fechar_caixa_janela" in c:
    c = padrao.sub(nova_funcao + "\n\n", c, count=1)
    with open(path, "w", encoding="utf-8") as f:
        f.write(c)
    print("OK - fechar_caixa_janela substituida (2 colunas)")
else:
    print("ERRO - funcao nao encontrada")