import json
import uuid as uuid_lib
from datetime import datetime
from database import conectar

# Simular o que o _alimentar_fila faz para a venda 1070
venda_id = 1070
tipo = "VENDA"
tabela = "vendas"

conn = conectar()
cur = conn.cursor()

# 1. Buscar a venda
cur.execute(f"SELECT id, uuid FROM {tabela} WHERE id = ?", (venda_id,))
row = cur.fetchone()

if not row:
    print(f"❌ Venda {venda_id} NAO ENCONTRADA")
    conn.close()
    exit()

rid, uuid_venda = row
print(f"Venda encontrada: id={rid} uuid={uuid_venda}")
print()

# 2. Tentar inserir directamente na fila
payload_json = "{}"
agora = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

try:
    cur.execute("""
        INSERT INTO fila_sincronizacao 
        (uuid, tipo, tabela_origem, registo_id, payload, estado, tentativas, criado_em)
        VALUES (?, ?, ?, ?, ?, 'PENDENTE', 0, ?)
    """, (uuid_venda, tipo, tabela, rid, payload_json, agora))
    conn.commit()
    print(f"✅ INSERIDO na fila com sucesso!")
except Exception as e:
    print(f"❌ ERRO ao inserir:")
    print(f"   {type(e).__name__}: {e}")

# 3. Ver se já existe
cur.execute("SELECT * FROM fila_sincronizacao WHERE uuid = ?", (uuid_venda,))
existente = cur.fetchall()
print()
print(f"Registos com este uuid na fila: {len(existente)}")
for e in existente:
    print(f"   {e}")

conn.close()