﻿from database import conectar


def main():
    conn = conectar()
    cur = conn.cursor()
    print("=" * 70)
    print("ERROS NA FILA")
    print("=" * 70)
    sql = "SELECT id, tipo, tabela_origem, registo_id, estado, tentativas, ultimo_erro FROM fila_sincronizacao WHERE estado = 'ERRO' LIMIT 10"
    cur.execute(sql)
    rows = cur.fetchall()
    print("Total de erros: " + str(len(rows)))
    print()
    for r in rows:
        print("ID=" + str(r[0]) + " | tipo=" + str(r[1]) + " | tabela=" + str(r[2]) + " | registo_id=" + str(r[3]))
        print("  estado=" + str(r[4]) + " | tentativas=" + str(r[5]))
        print("  ERRO: " + str(r[6]))
        print()
    conn.close()


if __name__ == "__main__":
    main()
