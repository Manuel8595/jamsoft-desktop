from database import conectar

conn = conectar()
cur = conn.cursor()

# Adicionar colunas em falta
try:
    cur.execute("ALTER TABLE metas_farmacia ADD COLUMN uuid TEXT")
    print("uuid adicionado")
except Exception as e:
    print(f"uuid: {e}")

try:
    cur.execute("ALTER TABLE metas_farmacia ADD COLUMN terminal_id TEXT")
    print("terminal_id adicionado")
except Exception as e:
    print(f"terminal_id: {e}")

try:
    cur.execute("ALTER TABLE metas_farmacia ADD COLUMN farmacia_id INTEGER")
    print("farmacia_id adicionado")
except Exception as e:
    print(f"farmacia_id: {e}")

try:
    cur.execute("ALTER TABLE metas_farmacia ADD COLUMN sincronizado INTEGER DEFAULT 0")
    print("sincronizado adicionado")
except Exception as e:
    print(f"sincronizado: {e}")

conn.commit()
conn.close()

print()
print("OK — metas_farmacia corrigida")