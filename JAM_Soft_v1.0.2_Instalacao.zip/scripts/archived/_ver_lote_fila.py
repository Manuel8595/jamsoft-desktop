from database import conectar
import fila_sync

conn = conectar()
cur = conn.cursor()

print("=" * 60)
print("FILA - ULTIMOS 20 REGISTOS")
print("=" * 60)
cur.execute("SELECT id, tipo, registo_id, estado, ultimo_erro FROM fila_sincronizacao ORDER BY id DESC LIMIT 20")
for r in cur.fetchall():
    err = (r[4] or "")[:50]
    print(f"id={r[0]} | {r[1]} | reg={r[2]} | {r[3]} | {err}")

print()
print("=" * 60)
print("LOTES NA FILA (qualquer estado)")
print("=" * 60)
cur.execute("SELECT id, tipo, registo_id, estado FROM fila_sincronizacao WHERE tipo = 'LOTE'")
rows = cur.fetchall()
if rows:
    for r in rows:
        print(f"id={r[0]} | tipo={r[1]} | reg={r[2]} | estado={r[3]}")
else:
    print("(NENHUM lote na fila! <- problema!)")

print()
print("=" * 60)
print("ESTATISTICAS")
print("=" * 60)
e = fila_sync.estatisticas()
for k, v in e.items():
    print(f"{k}: {v}")

print()
print("=" * 60)
print("PENDENTES (o que a fila tem pronto a enviar)")
print("=" * 60)
pend = fila_sync.listar_pendentes(20)
if pend:
    for p in pend:
        print(f"id={p[0]} | {p[2]} | reg={p[4]} | estado={p[6]}")
else:
    print("(NENHUM pendente)")

conn.close()