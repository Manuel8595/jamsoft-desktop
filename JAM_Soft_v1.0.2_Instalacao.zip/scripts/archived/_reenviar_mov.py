from database import conectar

conn = conectar()
cur = conn.cursor()

# 1. Apagar movimentos da fila
cur.execute("DELETE FROM fila_sincronizacao WHERE tipo = 'MOVIMENTO'")
print(f"Apagados da fila: {cur.rowcount}")

# 2. Marcar movimentos para sincronizar
cur.execute("UPDATE movimentos_caixa SET sincronizado = 0")
print(f"Marcados para sincronizar: {cur.rowcount}")

conn.commit()
conn.close()

print()
print("OK - corre F9 agora")