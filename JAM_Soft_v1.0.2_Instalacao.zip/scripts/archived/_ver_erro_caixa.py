from database import conectar

conn = conectar()
cur = conn.cursor()

print("=" * 60)
print("ERROS DOS CAIXAS NA FILA")
print("=" * 60)

cur.execute("""
    SELECT id, tipo, registo_id, estado, ultimo_erro, tentativas
    FROM fila_sincronizacao
    WHERE tipo = 'CAIXA'
    ORDER BY id DESC
""")

for r in cur.fetchall():
    print(f"fila_id={r[0]} | reg={r[2]} | estado={r[3]} | tent={r[5]}")
    print(f"   ERRO: {(r[4] or '(sem erro)')[:200]}")
    print()

conn.close()