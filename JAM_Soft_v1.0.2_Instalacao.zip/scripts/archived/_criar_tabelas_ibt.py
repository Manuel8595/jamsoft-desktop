"""
Cria as tabelas necessarias para o sistema IBT (Inter-Branch Transfer).
Uso: python _criar_tabelas_ibt.py
"""

from database import conectar


def criar_tabelas_ibt():
    conn = conectar()
    cur = conn.cursor()

    print("A criar tabelas locais...\n")

    # ================================================
    # TABELA 1: transferencias_filiais
    # ================================================
    cur.execute("""
        CREATE TABLE IF NOT EXISTS transferencias_filiais (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            referencia TEXT UNIQUE NOT NULL,
            data_criacao TEXT NOT NULL,
            data_envio TEXT,
            data_recepcao TEXT,

            farmacia_origem_id INTEGER,
            farmacia_origem_codigo TEXT,
            farmacia_origem_nome TEXT,

            farmacia_destino_id INTEGER,
            farmacia_destino_codigo TEXT,
            farmacia_destino_nome TEXT,

            utilizador_criou_id INTEGER,
            utilizador_criou_nome TEXT,
            autorizado_por TEXT,

            estado TEXT DEFAULT 'RASCUNHO',
            total_itens INTEGER DEFAULT 0,
            total_quantidade INTEGER DEFAULT 0,
            valor_estimado REAL DEFAULT 0,
            observacoes TEXT,

            uuid TEXT,
            terminal_id TEXT,
            farmacia_id INTEGER,
            sincronizado INTEGER DEFAULT 0
        )
    """)
    print("  OK - transferencias_filiais")

    # ================================================
    # TABELA 2: itens_transferencia
    # ================================================
    cur.execute("""
        CREATE TABLE IF NOT EXISTS itens_transferencia (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            transferencia_id INTEGER NOT NULL,
            produto_id INTEGER,
            produto_nome TEXT,
            codigo_barras TEXT,
            quantidade_enviada INTEGER DEFAULT 0,
            quantidade_recebida INTEGER DEFAULT 0,
            diferenca INTEGER DEFAULT 0,
            lote TEXT,
            validade TEXT,
            preco_custo REAL DEFAULT 0,
            subtotal REAL DEFAULT 0,
            justificacao TEXT,
            FOREIGN KEY (transferencia_id) REFERENCES transferencias_filiais(id)
        )
    """)
    print("  OK - itens_transferencia")

    # ================================================
    # TABELA 3: historico_ibt
    # ================================================
    cur.execute("""
        CREATE TABLE IF NOT EXISTS historico_ibt (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            transferencia_id INTEGER NOT NULL,
            data TEXT NOT NULL,
            acao TEXT NOT NULL,
            utilizador_nome TEXT,
            estado_anterior TEXT,
            estado_novo TEXT,
            detalhes TEXT,
            FOREIGN KEY (transferencia_id) REFERENCES transferencias_filiais(id)
        )
    """)
    print("  OK - historico_ibt")

    # ================================================
    # TABELA 4: farmacias (espelho local)
    # ================================================
    cur.execute("""
        CREATE TABLE IF NOT EXISTS farmacias (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            uuid TEXT UNIQUE,
            codigo TEXT UNIQUE NOT NULL,
            nome TEXT NOT NULL,
            nif TEXT,
            endereco TEXT,
            telefone TEXT,
            email TEXT,
            responsavel TEXT,
            notas TEXT,
            activo INTEGER DEFAULT 1,
            criado_em TEXT,
            ultima_sincronizacao TEXT,
            sincronizado INTEGER DEFAULT 0
        )
    """)
    print("  OK - farmacias (espelho local)")

    # ================================================
    # Colunas em falta (se existirem)
    # ================================================
    print("\nA verificar colunas...")
    colunas_a_verificar = [
        ("transferencias_filiais", "uuid"),
        ("transferencias_filiais", "terminal_id"),
        ("transferencias_filiais", "farmacia_id"),
        ("transferencias_filiais", "sincronizado"),
        ("farmacias", "uuid"),
        ("farmacias", "sincronizado"),
        ("farmacias", "ultima_sincronizacao"),
    ]

    for tabela, coluna in colunas_a_verificar:
        try:
            cur.execute(f"PRAGMA table_info({tabela})")
            cols = [c[1] for c in cur.fetchall()]
            if coluna not in cols:
                tipo = "INTEGER DEFAULT 0" if coluna == "sincronizado" else "TEXT"
                cur.execute(f"ALTER TABLE {tabela} ADD COLUMN {coluna} {tipo}")
                print(f"  + {tabela}.{coluna} adicionada")
        except Exception as e:
            print(f"  ! {tabela}.{coluna}: {e}")

    conn.commit()
    conn.close()

    print()
    print("=" * 60)
    print("OK - Todas as tabelas IBT foram criadas!")
    print("=" * 60)


def verificar_tabelas():
    """Verifica se as tabelas foram criadas correctamente."""
    conn = conectar()
    cur = conn.cursor()

    print("\n=== VERIFICACAO ===")
    for tabela in ["transferencias_filiais", "itens_transferencia",
                   "historico_ibt", "farmacias"]:
        cur.execute(f"PRAGMA table_info({tabela})")
        cols = cur.fetchall()
        print(f"\n{tabela} ({len(cols)} colunas):")
        for c in cols:
            print(f"  - {c[1]} ({c[2]})")

    # Contar filiais registadas
    cur.execute("SELECT COUNT(*) FROM farmacias")
    n = cur.fetchone()[0]
    print(f"\nFiliais registadas: {n}")

    conn.close()


if __name__ == "__main__":
    criar_tabelas_ibt()
    verificar_tabelas()