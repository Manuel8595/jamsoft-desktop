
from database import conectar

def main():
    conn = conectar()
    cur = conn.cursor()
    print('=' * 50)
    print('FILA POR ESTADO')
    print('=' * 50)
    cur.execute('SELECT COUNT(*), estado FROM fila_sincronizacao GROUP BY estado')
    for estado, count in cur.fetchall():
        print(f'  {estado}: {count}')
    cur.execute('SELECT COUNT(*) FROM fila_sincronizacao')
    print(f'Total: {cur.fetchone()[0]}')
    print()
    print('EXEMPLOS ITEN_VENDA:')
    cur.execute(chr(34)+'SELECT id, uuid, tipo, estado, tentativas FROM fila_sincronizacao WHERE tipo = '+chr(39)+'ITEN_VENDA'+chr(39)+' LIMIT 5'+chr(34))
    for r in cur.fetchall():
        u = r[1][:15] if r[1] else '(sem uuid)'
        print(f'  id={r[0]} uuid={u} estado={r[3]} tent={r[4]}')
    print()
    print('EXEMPLOS PRODUTO:')
    cur.execute(chr(34)+'SELECT id, uuid, tipo, estado, tentativas FROM fila_sincronizacao WHERE tipo = '+chr(39)+'PRODUTO'+chr(39)+' LIMIT 5'+chr(34))
    for r in cur.fetchall():
        u = r[1][:15] if r[1] else '(sem uuid)'
        print(f'  id={r[0]} uuid={u} estado={r[3]} tent={r[4]}')
    conn.close()

if __name__ == '__main__':
    main()
