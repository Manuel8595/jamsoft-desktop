from database import conectar

conn = conectar()
cur = conn.cursor()

# 1. Marcar erros antigos como PENDENTE (tentar outra vez com timeout novo)
cur.execute("""
    UPDATE fila_sincronizacao
    SET estado = 'PENDENTE',
        tentativas = 0,
        ultimo_erro = NULL
    WHERE estado = 'ERRO'
""")
print(f"OK: {cur.rowcount} erros marcados como PENDENTE")

# 2. Ver estado actual
cur.execute("SELECT estado, COUNT(*) FROM fila_sincronizacao GROUP BY estado")
print()
print("Estado actual da fila:")
for estado, qtd in cur.fetchall():
    print(f"  {estado:15} {qtd}")

conn.commit()
conn.close()