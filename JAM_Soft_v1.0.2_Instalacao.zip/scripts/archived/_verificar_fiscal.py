import os

print("=== VERIFICACAO DO fiscal.py ===\n")

if not os.path.exists("fiscal.py"):
    print("ERRO: fiscal.py NAO existe!")
    exit()

with open("fiscal.py", "r", encoding="utf-8") as f:
    conteudo = f.read()

linhas = conteudo.split("\n")
print(f"Total de linhas: {len(linhas)}")
print()

# 1. Contar ocorrencias
print("--- Ocorrencias no ficheiro ---")
print(f"'def abrir_fiscal': {conteudo.count('def abrir_fiscal')}")
print(f"'Listar Facturas': {conteudo.count('Listar Facturas')}")
print(f"'Listar Proformas': {conteudo.count('Listar Proformas')}")
print(f"'def listar_proformas_janela': {conteudo.count('def listar_proformas_janela')}")
print(f"'def ver_proforma_janela': {conteudo.count('def ver_proforma_janela')}")
print()

# 2. Mostrar o bloco dos botoes (procurar "frame_botoes")
print("--- Bloco do frame_botoes ---")
for i, linha in enumerate(linhas, 1):
    if "frame_botoes = Frame" in linha:
        # Mostrar as proximas 25 linhas
        for j in range(i, min(i + 25, len(linhas))):
            print(f"  {j}: {linhas[j-1]}")
        break
else:
    print("  Nao encontrei 'frame_botoes = Frame'")

print()
print("--- Ultimas 5 linhas do ficheiro ---")
for i, linha in enumerate(linhas[-5:], len(linhas) - 4):
    print(f"  {i}: {repr(linha)}")