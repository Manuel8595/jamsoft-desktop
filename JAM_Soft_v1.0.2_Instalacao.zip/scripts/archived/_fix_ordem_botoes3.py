"""
Corrige a ordem dos botoes na Lista IBT.
Move o frame_btn para DEPOIS das funcoes serem definidas.
Uso: python _fix_ordem_botoes3.py
"""

path = "transferencias.py"

with open(path, encoding="utf-8") as f:
    c = f.read()

# ============================================================
# 1. Encontrar e remover o bloco actual dos botoes
# ============================================================
bloco_antigo = '''    # ============================================================
    # BARRA DE BOTOES FIXA EM BAIXO
    # ============================================================
    frame_btn = Frame(janela, bg=COR_CARD, height=80)
    frame_btn.pack(fill=X, side=BOTTOM)
    frame_btn.pack_propagate(False)

    estilo = {"font": ("Segoe UI", 10, "bold"),
              "bd": 0, "cursor": "hand2", "fg": "white",
              "width": 15, "height": 2}

    Button(frame_btn, text="▶️ Continuar",
           bg=COR_DOURADO, fg="#0f172a",
           command=continuar_rascunho, **estilo).pack(side=LEFT, padx=6, pady=15)
    Button(frame_btn, text="🔍 Ver Detalhes",
           bg=COR_AZUL, command=ver_detalhes, **estilo).pack(side=LEFT, padx=6, pady=15)
    Button(frame_btn, text="📥 Receber",
           bg=COR_VERDE, command=receber, **estilo).pack(side=LEFT, padx=6, pady=15)
    Button(frame_btn, text="🔄 Actualizar",
           bg="#64748b", command=carregar, **estilo).pack(side=LEFT, padx=6, pady=15)
    Button(frame_btn, text="❌ Fechar",
           bg=COR_VERMELHO,
           command=janela.destroy, **estilo).pack(side=RIGHT, padx=6, pady=15)

'''

if bloco_antigo in c:
    c = c.replace(bloco_antigo, "")
    print("OK - bloco antigo removido (do inicio)")
else:
    # Tentar variante sem espacos a mais
    bloco_alt = '''    frame_btn = Frame(janela, bg=COR_CARD, height=80)
    frame_btn.pack(fill=X, side=BOTTOM)
    frame_btn.pack_propagate(False)

    estilo = {"font": ("Segoe UI", 10, "bold"),
              "bd": 0, "cursor": "hand2", "fg": "white",
              "width": 15, "height": 2}

    Button(frame_btn, text="▶️ Continuar",
           bg=COR_DOURADO, fg="#0f172a",
           command=continuar_rascunho, **estilo).pack(side=LEFT, padx=6, pady=15)
    Button(frame_btn, text="🔍 Ver Detalhes",
           bg=COR_AZUL, command=ver_detalhes, **estilo).pack(side=LEFT, padx=6, pady=15)
    Button(frame_btn, text="📥 Receber",
           bg=COR_VERDE, command=receber, **estilo).pack(side=LEFT, padx=6, pady=15)
    Button(frame_btn, text="🔄 Actualizar",
           bg="#64748b", command=carregar, **estilo).pack(side=LEFT, padx=6, pady=15)
    Button(frame_btn, text="❌ Fechar",
           bg=COR_VERMELHO,
           command=janela.destroy, **estilo).pack(side=RIGHT, padx=6, pady=15)'''

    if bloco_alt in c:
        c = c.replace(bloco_alt, "")
        print("OK - bloco antigo removido (variante)")
    else:
        print("AVISO - bloco antigo NAO encontrado - verifica manualmente")

# ============================================================
# 2. Encontrar o final de continuar_rascunho e inserir AQUI
# ============================================================
marcador = '''        abrir_nova_ibt(utilizador, janela, callback=carregar,
                        trans_id_existente=tid)

    frame_tab = Frame(janela, bg=COR_FUNDO)'''

novo = '''        abrir_nova_ibt(utilizador, janela, callback=carregar,
                        trans_id_existente=tid)

    # ============================================================
    # BARRA DE BOTOES FIXA EM BAIXO (depois das funcoes!)
    # ============================================================
    frame_btn = Frame(janela, bg=COR_CARD, height=80)
    frame_btn.pack(fill=X, side=BOTTOM)
    frame_btn.pack_propagate(False)

    estilo = {"font": ("Segoe UI", 10, "bold"),
              "bd": 0, "cursor": "hand2", "fg": "white",
              "width": 15, "height": 2}

    Button(frame_btn, text="▶️ Continuar",
           bg=COR_DOURADO, fg="#0f172a",
           command=continuar_rascunho, **estilo).pack(side=LEFT, padx=6, pady=15)
    Button(frame_btn, text="🔍 Ver Detalhes",
           bg=COR_AZUL, command=ver_detalhes, **estilo).pack(side=LEFT, padx=6, pady=15)
    Button(frame_btn, text="📥 Receber",
           bg=COR_VERDE, command=receber, **estilo).pack(side=LEFT, padx=6, pady=15)
    Button(frame_btn, text="🔄 Actualizar",
           bg="#64748b", command=carregar, **estilo).pack(side=LEFT, padx=6, pady=15)
    Button(frame_btn, text="❌ Fechar",
           bg=COR_VERMELHO,
           command=janela.destroy, **estilo).pack(side=RIGHT, padx=6, pady=15)

    frame_tab = Frame(janela, bg=COR_FUNDO)'''

if marcador in c:
    c = c.replace(marcador, novo)
    print("OK - bloco dos botoes reinserido (depois das funcoes)")
else:
    print("AVISO - marcador 'continuar_rascunho -> frame_tab' NAO encontrado")

with open(path, "w", encoding="utf-8") as f:
    f.write(c)

print()
print("=" * 60)
print("OK - Ordem corrigida!")
print("=" * 60)