path = "pdv.py"

with open(path, encoding="utf-8") as f:
    linhas = f.readlines()

# Encontrar o inicio da def concluir
inicio = None
for i, l in enumerate(linhas):
    if "        def concluir(forma, total, cliente_id" in l:
        inicio = i
        break

if inicio is None:
    print("ERRO: nao encontrei a def concluir")
    exit(1)

print(f"def concluir encontrada na linha {inicio + 1}")

# Encontrar o fim: proxima linha com "    def " (4 espacos) OU "# ===="
fim = None
for i in range(inicio + 1, len(linhas)):
    l = linhas[i]
    if l.startswith("    def ") or l.startswith("# ============"):
        fim = i
        break

if fim is None:
    fim = len(linhas)

print(f"Fim: linha {fim}")
print(f"Vou remover 4 espacos de {fim - inicio - 1} linhas")

# Remover 4 espacos de cada linha dentro da funcao
for i in range(inicio + 1, fim):
    l = linhas[i]
    if l.startswith("    ") and l.strip():
        linhas[i] = l[4:]

# Corrigir tambem a propria def (de 8 para 4 espacos)
linhas[inicio] = linhas[inicio][4:]

with open(path, "w", encoding="utf-8") as f:
    f.writelines(linhas)

print("OK - ficheiro corrigido")