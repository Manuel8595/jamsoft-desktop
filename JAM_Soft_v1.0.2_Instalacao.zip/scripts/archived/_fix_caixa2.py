path = "caixa.py"

with open(path, encoding="utf-8") as f:
    conteudo = f.read()

# Corrigir strings f-strings que ficaram quebradas
conteudo = conteudo.replace(
    'f"Saida registada!\n\nValor: {formatar_kz(valor)}\n'
    '                f"Categoria: {categoria}\nDescricao: {descricao}"',
    'f"Saida registada!\\n\\nValor: {formatar_kz(valor)}\\n"\n'
    '                f"Categoria: {categoria}\\nDescricao: {descricao}"'
)

conteudo = conteudo.replace(
    'f"Entrada registada!\n\nValor: {formatar_kz(valor)}\n'
    '                f"Categoria: {categoria}\nDescricao: {descricao}"',
    'f"Entrada registada!\\n\\nValor: {formatar_kz(valor)}\\n"\n'
    '                f"Categoria: {categoria}\\nDescricao: {descricao}"'
)

with open(path, "w", encoding="utf-8") as f:
    f.write(conteudo)

print("OK - ficheiro corrigido")