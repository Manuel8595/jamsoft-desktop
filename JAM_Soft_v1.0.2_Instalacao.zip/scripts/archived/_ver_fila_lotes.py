from database import conectar

conn = conectar()
cur = conn.cursor()

print("=" * 60)
print("LOTE L001")
print("=" * 60)
cur.execute("SELECT id, numero_lote, quantidade, uuid, sincronizado FROM lotes WHERE id = 1")
r = cur.fetchone()
if r:
    print(f"ID={r[0]} | Lote={r[1]} | Qtd={r[2]} | UUID={r[3]} | Sinc={r[4]}")
    if not r[3]:
        print(">>> PROBLEMA: uuid é NULL! <<<")
    if r[4] == 0:
        print(">>> Marcado para sincronizar <<<")

print()
print("=" * 60)
print("TODOS OS LOTES")
print("=" * 60)
cur.execute("SELECT id, produto_nome, numero_lote, quantidade, uuid, sincronizado FROM lotes")
for r in cur.fetchall():
    uuid_txt = (r[4] or "NULL")[:20]
    print(f"ID={r[0]} | {r[1]} | Lote={r[2]} | Qtd={r[3]} | UUID={uuid_txt} | Sinc={r[5]}")

print()
print("=" * 60)
print("FILA - LOTES")
print("=" * 60)
cur.execute("SELECT id, tipo, registo_id, estado FROM fila_sincronizacao WHERE tipo = 'LOTE' ORDER BY id DESC LIMIT 10")
resultados = cur.fetchall()
if resultados:
    for r in resultados:
        print(f"fila_id={r[0]} | tipo={r[1]} | registo={r[2]} | estado={r[3]}")
else:
    print("(nenhum lote na fila)")

conn.close()