import re

path = "caixa.py"

with open(path, encoding="utf-8") as f:
    conteudo = f.read()

# ─── Nova função fechar_caixa_janela ───
nova_funcao = '''def fechar_caixa_janela(cx_id, utilizador_logado, parent):
    """Fecho de caixa com contagem de notas + TPA + senha gerente."""

    dados = atualizar_totais_caixa(cx_id)
    esperado_cash = dados["valor_esperado"]
    esperado_tpa = dados.get("total_tpa", 0) or 0
    fundo_inicial = dados["valor_inicial"]

    janela = Toplevel(parent)
    janela.title("Fechar Caixa - Contagem")
    janela.geometry("750x900")
    janela.configure(bg=COR_FUNDO)
    janela.transient(parent)
    janela.grab_set()

    janela.update_idletasks()
    x = (janela.winfo_screenwidth() - 750) // 2
    y = (janela.winfo_screenheight() - 900) // 2
    janela.geometry(f"750x900+{x}+{y}")

    header = Frame(janela, bg="#be185d", height=70)
    header.pack(fill=X)
    header.pack_propagate(False)
    Label(header, text="FECHO DE CAIXA - CONTAGEM",
          font=("Segoe UI", 16, "bold"),
          bg="#be185d", fg="white").pack(pady=20)

    canvas = Canvas(janela, bg=COR_FUNDO, highlightthickness=0)
    scrollbar = Scrollbar(janela, orient="vertical", command=canvas.yview)
    scrollable = Frame(canvas, bg=COR_FUNDO)

    scrollable.bind("<Configure>",
                     lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.create_window((0, 0), window=scrollable, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.pack(side="left", fill="both", expand=True, padx=20, pady=10)
    scrollbar.pack(side="right", fill="y")

    Label(scrollable, text="RESUMO DO SISTEMA",
          font=("Segoe UI", 12, "bold"),
          bg=COR_FUNDO, fg=COR_TEXTO).pack(anchor=W, pady=(10, 5))

    card = Frame(scrollable, bg=COR_CARD, highlightthickness=1,
                  highlightbackground="#cbd5e1")
    card.pack(fill=X, pady=5)

    def _linha_resumo(parent, label, valor, cor=COR_TEXTO):
        f = Frame(parent, bg=COR_CARD)
        f.pack(fill=X, padx=15, pady=3)
        Label(f, text=label, font=("Segoe UI", 10),
              bg=COR_CARD, fg="#64748b").pack(side=LEFT)
        Label(f, text=valor, font=("Segoe UI", 11, "bold"),
              bg=COR_CARD, fg=cor).pack(side=RIGHT)

    _linha_resumo(card, "Fundo inicial:", formatar_kz(fundo_inicial))
    _linha_resumo(card, "+ Vendas Dinheiro:",
                   formatar_kz(dados["total_vendas"]), COR_VERDE)
    _linha_resumo(card, "+ Reforcos:",
                   formatar_kz(dados["total_reforcos"]), COR_VERDE)
    _linha_resumo(card, "- Sangrias:",
                   formatar_kz(dados["total_sangrias"]), COR_PERIGO)
    _linha_resumo(card, "ESPERADO EM CASH:",
                   formatar_kz(esperado_cash), COR_PRIMARIA)
    _linha_resumo(card, "ESPERADO EM TPA:",
                   formatar_kz(esperado_tpa), "#0891b2")

    Label(scrollable, text="CONTAGEM DE DINHEIRO (CASH)",
          font=("Segoe UI", 12, "bold"),
          bg=COR_FUNDO, fg=COR_TEXTO).pack(anchor=W, pady=(15, 5))

    card_notas = Frame(scrollable, bg=COR_CARD, highlightthickness=1,
                        highlightbackground="#cbd5e1")
    card_notas.pack(fill=X, pady=5)

    NOTAS = [5000, 2000, 1000, 500, 200, 100, 50, 20, 10]
    entries_notas = {}

    total_contado_var = StringVar(value="Kz 0,00")
    diff_cash_var = StringVar(value="—")

    def _atualizar_total_cash(*args):
        total = 0
        for nota, entry in entries_notas.items():
            try:
                qtd = int(entry.get() or 0)
                total += qtd * nota
            except ValueError:
                pass
        total_contado_var.set(formatar_kz(total))

        dif = total - esperado_cash
        if abs(dif) < 0.01:
            diff_cash_var.set("OK")
        elif dif > 0:
            diff_cash_var.set(f"SOBRA: {formatar_kz(dif)}")
        else:
            diff_cash_var.set(f"FALTA: {formatar_kz(abs(dif))}")

    for nota in NOTAS:
        linha = Frame(card_notas, bg=COR_CARD)
        linha.pack(fill=X, padx=15, pady=2)

        Label(linha, text=f"Kz {nota:,.0f}".replace(",", "."),
              font=("Segoe UI", 10, "bold"),
              bg=COR_CARD, fg=COR_TEXTO, width=10, anchor=W).pack(side=LEFT)

        e = Entry(linha, font=("Segoe UI", 11), width=8,
                   justify=CENTER, bd=1, relief=SOLID)
        e.pack(side=LEFT, padx=10, ipady=4)
        e.insert(0, "0")
        entries_notas[nota] = e

        sub_var = StringVar(value="Kz 0,00")
        Label(linha, textvariable=sub_var,
               font=("Segoe UI", 10, "bold"),
               bg=COR_CARD, fg=COR_PRIMARIA,
               width=20, anchor=E).pack(side=RIGHT)

        def _fazer_cb(nota_ref, entry_ref, sub_var_ref):
            def _cb(*args):
                try:
                    qtd = int(entry_ref.get() or 0)
                    sub_var_ref.set(formatar_kz(qtd * nota_ref))
                except ValueError:
                    sub_var_ref.set("Kz 0,00")
                _atualizar_total_cash()
            return _cb

        e.bind("<KeyRelease>", _fazer_cb(nota, e, sub_var))

    total_frame = Frame(card_notas, bg="#f1f5f9")
    total_frame.pack(fill=X, padx=15, pady=(10, 15))

    Label(total_frame, text="TOTAL CONTADO CASH:",
          font=("Segoe UI", 11, "bold"),
          bg="#f1f5f9", fg=COR_TEXTO).pack(side=LEFT, padx=10, pady=8)
    Label(total_frame, textvariable=total_contado_var,
          font=("Segoe UI", 13, "bold"),
          bg="#f1f5f9", fg=COR_PRIMARIA).pack(side=LEFT, padx=5)

    Label(total_frame, text="  |  DIFERENÇA:",
          font=("Segoe UI", 10, "bold"),
          bg="#f1f5f9", fg=COR_TEXTO).pack(side=LEFT, padx=(20, 5))
    diff_lbl = Label(total_frame, textvariable=diff_cash_var,
                      font=("Segoe UI", 11, "bold"),
                      bg="#f1f5f9", fg=COR_ALERTA)
    diff_lbl.pack(side=LEFT)

    def _colorir_diff(*args):
        txt = diff_cash_var.get()
        if "OK" in txt:
            diff_lbl.config(fg=COR_VERDE)
        elif "SOBRA" in txt:
            diff_lbl.config(fg=COR_ALERTA)
        else:
            diff_lbl.config(fg=COR_PERIGO)

    diff_cash_var.trace("w", _colorir_diff)

    Label(scrollable, text="CONTAGEM TPA (CARTAO)",
          font=("Segoe UI", 12, "bold"),
          bg=COR_FUNDO, fg=COR_TEXTO).pack(anchor=W, pady=(15, 5))

    card_tpa = Frame(scrollable, bg=COR_CARD, highlightthickness=1,
                      highlightbackground="#cbd5e1")
    card_tpa.pack(fill=X, pady=5)

    f1 = Frame(card_tpa, bg=COR_CARD)
    f1.pack(fill=X, padx=15, pady=8)
    Label(f1, text="Nº de talões TPA:",
          font=("Segoe UI", 11, "bold"),
          bg=COR_CARD, fg=COR_TEXTO, width=20, anchor=W).pack(side=LEFT)
    entry_taloes = Entry(f1, font=("Segoe UI", 12), width=12,
                          justify=CENTER, bd=1, relief=SOLID)
    entry_taloes.pack(side=LEFT, padx=10, ipady=5)
    entry_taloes.insert(0, "0")

    f2 = Frame(card_tpa, bg=COR_CARD)
    f2.pack(fill=X, padx=15, pady=8)
    Label(f2, text="Valor total dos talões (Kz):",
          font=("Segoe UI", 11, "bold"),
          bg=COR_CARD, fg=COR_TEXTO, width=20, anchor=W).pack(side=LEFT)
    entry_tpa_valor = Entry(f2, font=("Segoe UI", 12), width=20,
                             justify=CENTER, bd=1, relief=SOLID)
    entry_tpa_valor.pack(side=LEFT, padx=10, ipady=5)

    diff_tpa_var = StringVar(value="—")

    def _calc_diff_tpa(*args):
        try:
            valor_txt = entry_tpa_valor.get().replace(".", "").replace(",", ".")
            valor = float(valor_txt or 0)
            dif = valor - esperado_tpa
            if abs(dif) < 0.01:
                diff_tpa_var.set("OK")
            elif dif > 0:
                diff_tpa_var.set(f"SOBRA: {formatar_kz(dif)}")
            else:
                diff_tpa_var.set(f"FALTA: {formatar_kz(abs(dif))}")
        except ValueError:
            diff_tpa_var.set("—")

    entry_tpa_valor.bind("<KeyRelease>", _calc_diff_tpa)

    Label(card_tpa, text="ESPERADO TPA:",
          font=("Segoe UI", 11, "bold"),
          bg=COR_CARD, fg=COR_TEXTO).pack(anchor=W, padx=15, pady=(8, 2))
    Label(card_tpa, text=formatar_kz(esperado_tpa),
          font=("Segoe UI", 12, "bold"),
          bg=COR_CARD, fg="#0891b2").pack(anchor=W, padx=15)

    Label(card_tpa, text="DIFERENÇA TPA:",
          font=("Segoe UI", 11, "bold"),
          bg=COR_CARD, fg=COR_TEXTO).pack(anchor=W, padx=15, pady=(8, 2))
    Label(card_tpa, textvariable=diff_tpa_var,
          font=("Segoe UI", 12, "bold"),
          bg=COR_CARD, fg=COR_ALERTA).pack(anchor=W, padx=15, pady=(0, 15))

    Label(scrollable, text="VALOR A DEPOSITAR",
          font=("Segoe UI", 12, "bold"),
          bg=COR_FUNDO, fg=COR_TEXTO).pack(anchor=W, pady=(15, 5))

    card_dep = Frame(scrollable, bg="#dcfce7", highlightthickness=1,
                      highlightbackground="#16a34a")
    card_dep.pack(fill=X, pady=5)

    Label(card_dep, text="Total contado cash - Fundo inicial:",
          font=("Segoe UI", 10),
          bg="#dcfce7", fg="#166534").pack(anchor=W, padx=15, pady=(10, 2))

    valor_depositar_var = StringVar(value="Kz 0,00")

    def _calc_depositar(*args):
        try:
            txt = total_contado_var.get().replace("Kz", "").replace(".", "").replace(",", ".").strip()
            total = float(txt or 0)
            dep = total - fundo_inicial
            valor_depositar_var.set(formatar_kz(dep) if dep > 0 else "Kz 0,00")
        except ValueError:
            valor_depositar_var.set("Kz 0,00")

    total_contado_var.trace("w", _calc_depositar)

    Label(card_dep, textvariable=valor_depositar_var,
          font=("Segoe UI", 16, "bold"),
          bg="#dcfce7", fg=COR_VERDE).pack(anchor=W, padx=15, pady=(0, 5))

    Label(card_dep, text=f"(Fundo a entregar ao gerente: {formatar_kz(fundo_inicial)})",
          font=("Segoe UI", 9, "italic"),
          bg="#dcfce7", fg="#166534").pack(anchor=W, padx=15, pady=(0, 12))

    Label(scrollable, text="Observações (obrigatório se SOBRA):",
          font=("Segoe UI", 11, "bold"),
          bg=COR_FUNDO, fg=COR_TEXTO).pack(anchor=W, pady=(15, 5))

    entry_obs = Entry(scrollable, font=("Segoe UI", 11),
                       bd=1, relief=SOLID)
    entry_obs.pack(fill=X, pady=5, ipady=8)

    frame_btn = Frame(scrollable, bg=COR_FUNDO)
    frame_btn.pack(fill=X, pady=25)

    def confirmar():
        try:
            txt = total_contado_var.get().replace("Kz", "").replace(".", "").replace(",", ".").strip()
            total_cash = float(txt or 0)
        except ValueError:
            messagebox.showerror("Erro", "Valor contado cash invalido.")
            return

        try:
            tpa_txt = entry_tpa_valor.get().replace(".", "").replace(",", ".")
            total_tpa = float(tpa_txt or 0)
        except ValueError:
            messagebox.showerror("Erro", "Valor TPA invalido.")
            return

        try:
            num_taloes = int(entry_taloes.get() or 0)
        except ValueError:
            num_taloes = 0

        diff_cash = total_cash - esperado_cash
        observacoes = entry_obs.get().strip()

        # FALTA cash -> bloqueia
        if diff_cash < -0.01:
            messagebox.showerror("FALTA em Cash",
                f"Nao e possivel fechar!\\n\\n"
                f"FALTA em dinheiro: {formatar_kz(abs(diff_cash))}\\n\\n"
                f"Reconte o dinheiro antes de fechar.")
            return

        # SOBRA -> obriga observacao
        if diff_cash > 0.01 and not observacoes:
            messagebox.showwarning("Observação obrigatória",
                "Ha sobra no caixa.\\n\\n"
                "Tem de escrever o motivo nas observações.")
            return

        if not messagebox.askyesno("Confirmar Fecho",
            f"Fechar o caixa?\\n\\n"
            f"Cash: {formatar_kz(total_cash)}\\n"
            f"TPA:  {formatar_kz(total_tpa)} ({num_taloes} taloes)\\n"
            f"Depositar: {valor_depositar_var.get()}"):
            return

        from caixa import _pedir_autorizacao_gerente
        ok, nome_gerente = _pedir_autorizacao_gerente(
            janela,
            f"Fecho do caixa #{cx_id}",
            utilizador_logado
        )
        if not ok:
            return

        detalhe = {}
        for nota, entry in entries_notas.items():
            try:
                qtd = int(entry.get() or 0)
                if qtd > 0:
                    detalhe[str(nota)] = qtd
            except ValueError:
                pass

        try:
            resultado = fechar_caixa(
                cx_id, utilizador_logado["id"], utilizador_logado["nome"],
                total_cash, observacoes,
                contado_tpa=total_tpa,
                num_taloes_tpa=num_taloes,
                detalhe_notas=detalhe
            )

            registar_auditoria(
                utilizador_logado["id"], utilizador_logado["nome"],
                "FECHO CAIXA",
                f"Caixa #{cx_id} | Cash: {formatar_kz(total_cash)} | "
                f"TPA: {formatar_kz(total_tpa)} | "
                f"Autorizado por: {nome_gerente}"
            )

            messagebox.showinfo("Caixa Fechado",
                f"CAIXA #{cx_id} FECHADO!\\n\\n"
                f"Cash: {formatar_kz(total_cash)}\\n"
                f"TPA:  {formatar_kz(total_tpa)}\\n"
                f"Depositar: {valor_depositar_var.get()}\\n"
                f"Fundo ao gerente: {formatar_kz(fundo_inicial)}\\n\\n"
                f"Autorizado por: {nome_gerente}")

            janela.destroy()
            parent.destroy()
            abrir_caixa_menu(utilizador_logado)

        except Exception as e:
            import traceback
            traceback.print_exc()
            messagebox.showerror("Erro", f"Erro ao fechar caixa: {e}")

    Button(frame_btn, text="✅ Confirmar Fecho",
           font=("Segoe UI", 13, "bold"),
           bg="#be185d", fg="white",
           width=22, height=2, bd=0, cursor="hand2",
           command=confirmar).pack(side=LEFT, padx=5)

    Button(frame_btn, text="Cancelar",
           font=("Segoe UI", 11),
           bg="#6b7280", fg="white",
           width=15, height=2, bd=0, cursor="hand2",
           command=janela.destroy).pack(side=LEFT, padx=5)'''

# ─── Substituir a função antiga pela nova ───
padrao = re.compile(
    r"def fechar_caixa_janela\(cx_id, utilizador_logado, parent\):.*?(?=\ndef )",
    re.DOTALL
)

if "def fechar_caixa_janela" in conteudo:
    if "CONTAGEM DE DINHEIRO" in conteudo:
        print("JA SUBSTITUIDA - nao mexer")
    else:
        conteudo = padrao.sub(nova_funcao + "\n\n", conteudo, count=1)
        with open(path, "w", encoding="utf-8") as f:
            f.write(conteudo)
        print("OK - funcao fechar_caixa_janela substituida")
else:
    print("ERRO - funcao nao encontrada")