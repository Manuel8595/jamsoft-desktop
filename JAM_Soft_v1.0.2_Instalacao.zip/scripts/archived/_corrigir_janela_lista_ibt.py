"""
Corrige a janela da lista IBT para caber no ecra.
Uso: python _corrigir_janela_lista_ibt.py
"""

path = "transferencias.py"

with open(path, encoding="utf-8") as f:
    c = f.read()

# ============================================================
# 1. abrir_lista_ibt: usar zoomed + reduzir altura da tabela
# ============================================================

# Reduzir altura da tree de 18 para 12
antigo = '''    tree = ttk.Treeview(frame_tab, columns=colunas, show="headings", height=18)'''
novo = '''    tree = ttk.Treeview(frame_tab, columns=colunas, show="headings", height=12)'''

if antigo in c:
    c = c.replace(antigo, novo)
    print("OK - altura da tabela reduzida para 12")

# Botões: usar pack com pady menor + frame fixo em baixo
antigo_btns = '''    frame_btn = Frame(janela, bg=COR_FUNDO)
    frame_btn.pack(pady=10)

    estilo = {"font": ("Segoe UI", 11, "bold"),
              "bd": 0, "cursor": "hand2", "fg": "white",
              "width": 18, "height": 2}

    Button(frame_btn, text="▶️ Continuar",
           bg=COR_DOURADO, fg="#0f172a",
           command=continuar_rascunho, **estilo).pack(side=LEFT, padx=5)
    Button(frame_btn, text="🔍 Ver Detalhes",
           bg=COR_AZUL, command=ver_detalhes, **estilo).pack(side=LEFT, padx=5)
    Button(frame_btn, text="📥 Receber",
           bg=COR_VERDE, command=receber, **estilo).pack(side=LEFT, padx=5)
    Button(frame_btn, text="🔄 Actualizar",
           bg="#64748b", command=carregar, **estilo).pack(side=LEFT, padx=5)
    Button(frame_btn, text="❌ Fechar",
           bg=COR_VERMELHO,
           command=janela.destroy, **estilo).pack(side=RIGHT, padx=5)'''

novo_btns = '''    # Barra de botoes FIXA em baixo
    frame_btn = Frame(janela, bg=COR_CARD, height=80)
    frame_btn.pack(fill=X, side=BOTTOM)
    frame_btn.pack_propagate(False)

    estilo = {"font": ("Segoe UI", 10, "bold"),
              "bd": 0, "cursor": "hand2", "fg": "white",
              "width": 16, "height": 2}

    Button(frame_btn, text="▶️ Continuar",
           bg=COR_DOURADO, fg="#0f172a",
           command=continuar_rascunho, **estilo).pack(side=LEFT, padx=8, pady=15)
    Button(frame_btn, text="🔍 Ver Detalhes",
           bg=COR_AZUL, command=ver_detalhes, **estilo).pack(side=LEFT, padx=8, pady=15)
    Button(frame_btn, text="📥 Receber",
           bg=COR_VERDE, command=receber, **estilo).pack(side=LEFT, padx=8, pady=15)
    Button(frame_btn, text="🔄 Actualizar",
           bg="#64748b", command=carregar, **estilo).pack(side=LEFT, padx=8, pady=15)
    Button(frame_btn, text="❌ Fechar",
           bg=COR_VERMELHO,
           command=janela.destroy, **estilo).pack(side=RIGHT, padx=8, pady=15)'''

if antigo_btns in c:
    c = c.replace(antigo_btns, novo_btns)
    print("OK - barra de botoes fixa em baixo")
else:
    print("AVISO - bloco dos botoes nao encontrado")

with open(path, "w", encoding="utf-8") as f:
    f.write(c)

print()
print("=" * 60)
print("OK - janela da lista IBT corrigida!")
print("=" * 60)