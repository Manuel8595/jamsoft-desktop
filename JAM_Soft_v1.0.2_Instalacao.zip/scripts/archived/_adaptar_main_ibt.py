"""
Adiciona o botao "Transferencias" ao menu principal do JAM Soft.
Uso: python _adaptar_main_ibt.py
"""

path = "main.py"

with open(path, encoding="utf-8") as f:
    c = f.read()

# ============================================================
# 1. Adicionar import do abrir_transferencias
# ============================================================
if "from transferencias import" not in c:
    # Procurar a ultima linha de imports do projeto
    if "from permissoes import tem_permissao, NOMES_PERFIS" in c:
        c = c.replace(
            "from permissoes import tem_permissao, NOMES_PERFIS",
            "from permissoes import tem_permissao, NOMES_PERFIS\nfrom transferencias import abrir_transferencias"
        )
        print("OK - import adicionado")
    else:
        print("AVISO - import nao adicionado (padrao nao encontrado)")
else:
    print("OK - import ja existe")

# ============================================================
# 2. Adicionar a seccao "TRANSFERENCIAS" no menu
# ============================================================
seccao_transferencias = '''

# ============================================================
# ============ TRANSFERENCIAS ENTRE FILIAIS (IBT) ============
# ============================================================

pode_transferencias = (PERFIL in ("admin", "gerente") or
                        tem_permissao(PERFIL, "transferencias.ver"))

if pode_transferencias:
    criar_separador(scrollable, "TRANSFERENCIAS ENTRE FILIAIS", "#0ea5e9")
    linha_transf = criar_linha_botoes(scrollable)

    CardBotao(linha_transf, "Transferencias (IBT)",
               "Mover stock entre filiais", "",
               "#0ea5e9",
               lambda: abrir_transferencias(utilizador, root)
               ).grid(row=0, column=0, padx=5)

'''

# Adicionar antes da seccao "ADMINISTRACAO"
padrao_antes_admin = '''# ============================================================
# ============ ADMINISTRACAO =================================
# ============================================================'''

if padrao_antes_admin in c:
    c = c.replace(padrao_antes_admin,
                    seccao_transferencias + padrao_antes_admin)
    print("OK - seccao Transferencias adicionada")
else:
    print("AVISO - padrao ADMINISTRACAO nao encontrado")
    print("        verificar main.py manualmente")

# ============================================================
# Gravar
# ============================================================
with open(path, "w", encoding="utf-8") as f:
    f.write(c)

print()
print("=" * 60)
print("OK - main.py adaptado com o modulo IBT!")
print("=" * 60)