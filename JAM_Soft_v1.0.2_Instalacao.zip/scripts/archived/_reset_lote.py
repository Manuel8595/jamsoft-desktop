from database import conectar

conn = conectar()
cur = conn.cursor()

# Apagar o lote L001 da fila
cur.execute("DELETE FROM fila_sincronizacao WHERE tipo = 'LOTE' AND registo_id = 1")
apagados = cur.rowcount
print(f"Apagados da fila: {apagados}")

# Marcar o lote para sincronizar novamente
cur.execute("UPDATE lotes SET sincronizado = 0 WHERE id = 1")
print(f"Lotes marcados: {cur.rowcount}")

conn.commit()
conn.close()

print()
print("OK - Agora corre F9")