"""
Insere a barra de botoes no FIM da funcao abrir_lista_ibt.
Uso: python _fix_botoes_final.py
"""

path = "transferencias.py"

with open(path, encoding="utf-8") as f:
    linhas = f.readlines()

# ============================================================
# Encontrar a linha "def abrir_detalhes_ibt" (inicio da proxima funcao)
# ============================================================
idx_proxima = None
for i, l in enumerate(linhas):
    if l.startswith("def abrir_detalhes_ibt"):
        idx_proxima = i
        break

if idx_proxima is None:
    print("ERRO - nao encontrei 'def abrir_detalhes_ibt'")
    exit()

print(f"OK - 'def abrir_detalhes_ibt' na linha {idx_proxima + 1}")

# ============================================================
# Andar para tras para encontrar onde acaba a funcao anterior
# Procurar a ultima linha com conteudo ANTES de def abrir_detalhes_ibt
# ============================================================
idx_fim = idx_proxima - 1
while idx_fim > 0 and linhas[idx_fim].strip() == "":
    idx_fim -= 1

print(f"OK - ultima linha com conteudo da funcao anterior: {idx_fim + 1}")
print(f"     -> {linhas[idx_fim].rstrip()}")

# ============================================================
# Bloco dos botoes
# ============================================================
bloco_botoes = '''
    # ============================================================
    # BARRA DE BOTOES FIXA EM BAIXO
    # ============================================================
    frame_btn = Frame(janela, bg=COR_CARD, height=80)
    frame_btn.pack(fill=X, side=BOTTOM)
    frame_btn.pack_propagate(False)

    estilo = {"font": ("Segoe UI", 10, "bold"),
              "bd": 0, "cursor": "hand2", "fg": "white",
              "width": 15, "height": 2}

    Button(frame_btn, text="▶️ Continuar",
           bg=COR_DOURADO, fg="#0f172a",
           command=continuar_rascunho, **estilo).pack(side=LEFT, padx=6, pady=15)
    Button(frame_btn, text="🔍 Ver Detalhes",
           bg=COR_AZUL, command=ver_detalhes, **estilo).pack(side=LEFT, padx=6, pady=15)
    Button(frame_btn, text="📥 Receber",
           bg=COR_VERDE, command=receber, **estilo).pack(side=LEFT, padx=6, pady=15)
    Button(frame_btn, text="🔄 Actualizar",
           bg="#64748b", command=carregar, **estilo).pack(side=LEFT, padx=6, pady=15)
    Button(frame_btn, text="❌ Fechar",
           bg=COR_VERMELHO,
           command=janela.destroy, **estilo).pack(side=RIGHT, padx=6, pady=15)


'''

# ============================================================
# Inserir o bloco ANTES da proxima def
# ============================================================
linhas.insert(idx_proxima, bloco_botoes)

with open(path, "w", encoding="utf-8") as f:
    f.writelines(linhas)

print()
print("=" * 60)
print(f"OK - botoes inseridos na linha {idx_proxima + 1}")
print("=" * 60)