"""
Corrige a tabela farmacias: adiciona coluna 'activo' se nao existir.
Uso: python _corrigir_farmacias_coluna.py
"""

from database import conectar

conn = conectar()
cur = conn.cursor()

print("A verificar colunas de 'farmacias'...\n")

# Ver colunas existentes
cur.execute("PRAGMA table_info(farmacias)")
colunas = [c[1] for c in cur.fetchall()]
print(f"Colunas actuais: {colunas}\n")

# Adicionar 'activo' se nao existir
if "activo" not in colunas:
    print("A adicionar coluna 'activo'...")
    cur.execute("ALTER TABLE farmacias ADD COLUMN activo INTEGER DEFAULT 1")
    print("  OK - coluna 'activo' adicionada")

    # Copiar valores de 'ativo' para 'activo'
    if "ativo" in colunas:
        cur.execute("UPDATE farmacias SET activo = ativo")
        print(f"  OK - {cur.rowcount} registos copiados de 'ativo' para 'activo'")
else:
    print("  OK - coluna 'activo' ja existe")

# Verificar resultado
cur.execute("PRAGMA table_info(farmacias)")
colunas_final = [c[1] for c in cur.fetchall()]
print(f"\nColunas finais: {colunas_final}")

# Contar registos
cur.execute("SELECT COUNT(*) FROM farmacias")
n = cur.fetchone()[0]
print(f"\nTotal de farmacias: {n}")

cur.execute("SELECT COUNT(*) FROM farmacias WHERE activo = 1")
n_act = cur.fetchone()[0]
print(f"Activas: {n_act}")

conn.commit()
conn.close()

print()
print("=" * 60)
print("OK - Correcao concluida!")
print("=" * 60)