import re

path = "caixa.py"

with open(path, encoding="utf-8") as f:
    conteudo = f.read()

# Substituir "texto\n(real)continuação" por "texto\\ncontinuação"
# Padrão: dentro de strings, quebra real -> \\n

# Regex: encontra padrões tipo  "...\n   ..."
# onde \n é quebra real e os ... são texto

# Solução: substituir todas as quebras reais que estão DENTRO de aspas
# por \\n

# Padrão: aspas + qualquer coisa + quebra + qualquer coisa + aspas
padrao = re.compile(r'"([^"]*?)\n([^"]*?)"', re.DOTALL)

def _substituir(m):
    return '"' + m.group(1) + '\\n' + m.group(2) + '"'

# Aplicar várias vezes (nested)
for _ in range(10):
    novo = padrao.sub(_substituir, conteudo)
    if novo == conteudo:
        break
    conteudo = novo

with open(path, "w", encoding="utf-8") as f:
    f.write(conteudo)

print("OK - ficheiro corrigido com regex")