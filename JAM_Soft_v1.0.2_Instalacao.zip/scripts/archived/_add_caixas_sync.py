path = "sincronizacao.py"

with open(path, encoding="utf-8") as f:
    c = f.read()

# ─── 1. MAPA_TABELAS ───
antigo = '"META": "metas_farmacia",\n}'
novo = '"META": "metas_farmacia",\n    "CAIXA": "caixas",\n}'
if antigo in c:
    c = c.replace(antigo, novo)
    print("OK: MAPA_TABELAS")
else:
    print("AVISO: MAPA_TABELAS - verificar manualmente")

# ─── 2. _alimentar_fila mapeamento ───
antigo = '        ("metas_farmacia", "META"),\n    ]'
novo = '        ("metas_farmacia", "META"),\n        ("caixas", "CAIXA"),\n    ]'
if antigo in c:
    c = c.replace(antigo, novo)
    print("OK: mapeamento")
else:
    print("AVISO: mapeamento - verificar manualmente")

# ─── 3. contadores ───
antigo = '"META": "metas",\n        "CATEGORIA"'
novo = '"META": "metas",\n        "CAIXA": "caixas",\n        "CATEGORIA"'
if antigo in c:
    c = c.replace(antigo, novo)
    print("OK: contadores")
else:
    print("AVISO: contadores - verificar manualmente")

# ─── 4. resultado dict ───
antigo = '"metas": 0,\n        "categorias": 0'
novo = '"metas": 0, "caixas": 0,\n        "categorias": 0'
if antigo in c:
    c = c.replace(antigo, novo)
    print("OK: resultado")
else:
    print("AVISO: resultado - verificar manualmente")

# ─── 5. _preparar_payload - adicionar bloco CAIXA antes de CATEGORIA ───
antigo_bloco = '''    # ============ CATEGORIA ============
    elif tipo == "CATEGORIA":'''

novo_bloco = '''    # ============ CAIXA ============
    elif tipo == "CAIXA":
        cur.execute("""
            SELECT uuid, data_abertura, data_fecho,
                   utilizador_abertura_nome, utilizador_fecho_nome,
                   valor_inicial, total_vendas_dinheiro, total_sangrias,
                   total_reforcos, valor_esperado, valor_contado,
                   diferenca, estado, observacoes,
                   contado_tpa, num_taloes_tpa, detalhe_notas,
                   terminal_id
            FROM caixas WHERE id = ?
        """, (registo_id,))
        r = cur.fetchone()
        if r:
            payload = {
                "uuid": r[0],
                "farmacia_id": farmacia_id,
                "terminal_id": r[17],
                "data_abertura": r[1],
                "data_fecho": r[2],
                "utilizador_abertura_nome": r[3],
                "utilizador_fecho_nome": r[4],
                "valor_inicial": r[5],
                "total_vendas_dinheiro": r[6],
                "total_sangrias": r[7],
                "total_reforcos": r[8],
                "valor_esperado": r[9],
                "valor_contado": r[10],
                "diferenca": r[11],
                "estado": r[12],
                "observacoes": r[13],
                "contado_tpa": r[14] or 0,
                "num_taloes_tpa": r[15] or 0,
                "detalhe_notas": r[16],
            }

    # ============ CATEGORIA ============
    elif tipo == "CATEGORIA":'''

if antigo_bloco in c:
    c = c.replace(antigo_bloco, novo_bloco)
    print("OK: _preparar_payload CAIXA")
else:
    print("AVISO: _preparar_payload - verificar manualmente")

with open(path, "w", encoding="utf-8") as f:
    f.write(c)

print()
print("Ficheiro guardado")