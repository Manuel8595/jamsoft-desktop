from database import conectar
from collections import Counter

conn = conectar()
cur = conn.cursor()

# Ver os erros agrupados
print("=" * 70)
print("ERROS NA FILA (agrupados por tipo + mensagem)")
print("=" * 70)

cur.execute("""
    SELECT tipo, tabela_origem, ultimo_erro, COUNT(*) AS qtd
    FROM fila_sincronizacao
    WHERE estado = 'ERRO'
    GROUP BY tipo, tabela_origem, ultimo_erro
    ORDER BY qtd DESC
""")

for tipo, tabela, erro, qtd in cur.fetchall():
    print()
    print(f"❌ [{tipo}] {tabela} — {qtd} erro(s)")
    print(f"   {erro[:250] if erro else '(sem mensagem)'}")

print()
print("=" * 70)
print("RESUMO POR TIPO")
print("=" * 70)

cur.execute("""
    SELECT tipo, COUNT(*) FROM fila_sincronizacao
    WHERE estado = 'ERRO'
    GROUP BY tipo ORDER BY COUNT(*) DESC
""")

for tipo, qtd in cur.fetchall():
    print(f"  {tipo:25} {qtd}")

print()
print("=" * 70)
print("PENDENTES POR TIPO")
print("=" * 70)

cur.execute("""
    SELECT tipo, COUNT(*) FROM fila_sincronizacao
    WHERE estado = 'PENDENTE'
    GROUP BY tipo ORDER BY COUNT(*) DESC
""")

for tipo, qtd in cur.fetchall():
    print(f"  {tipo:25} {qtd}")

conn.close()