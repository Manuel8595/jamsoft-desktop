from database import conectar
from datetime import datetime

conn = conectar()
cur = conn.cursor()

hoje = datetime.now().strftime("%Y-%m-%d")

print("=" * 70)
print(f"VENDAS LOCAIS DE HOJE ({hoje})")
print("=" * 70)

cur.execute("""
    SELECT id, data, total, forma_pagamento, uuid, terminal_id,
           farmacia_id, sincronizado
    FROM vendas
    WHERE DATE(data) = DATE(?)
    ORDER BY id DESC
""", (hoje,))

for r in cur.fetchall():
    vid, data, total, fp, uuid_, term, farm, sinc = r
    print(f"ID={vid} | {data} | Kz {total:,.0f} | {fp}")
    print(f"   uuid={uuid_}")
    print(f"   terminal={term} | farmacia={farm} | sincronizado={sinc}")
    print()

print("=" * 70)
print("FILA — ULTIMAS 10 OPERACOES DE VENDA")
print("=" * 70)

cur.execute("""
    SELECT id, tipo, registo_id, estado, ultimo_erro
    FROM fila_sincronizacao
    WHERE tipo = 'VENDA'
    ORDER BY id DESC LIMIT 10
""")

for r in cur.fetchall():
    fid, tipo, reg, estado, erro = r
    print(f"fila_id={fid} tipo={tipo} registo={reg} estado={estado}")
    if erro:
        print(f"   ERRO: {erro[:150]}")

conn.close()