path = "caixa.py"

with open(path, encoding="utf-8") as f:
    linhas = f.readlines()

print(f"Antes: {len(linhas)} linhas")

# A linha 11 (índice 10) tem o código todo comprimido
linha_gigante = linhas[10]

# Diagnóstico
n_literais = linha_gigante.count("\\n")
print(f"Linha 11 tem {n_literais} \\n literais")

# Restaurar: substituir \n literais por quebras reais
linha_corrigida = linha_gigante.replace("\\n", "\n")

# Verificar se ficou com quebras reais
n_reais = linha_corrigida.count("\n")
print(f"Apos correcção: {n_reais} quebras reais")

# Reconstruir ficheiro:
# - Linhas 1-10 (índices 0-9): manter
# - Linha 11 (índice 10): substituir por versão corrigida
# - Linhas 12-13 (índices 11-12): manter (são o final do ficheiro)
novo_conteudo = "".join(linhas[:10]) + linha_corrigida + "\n" + "".join(linhas[11:])

# Backup
with open("caixa.py.bak", "w", encoding="utf-8") as f:
    f.write("".join(linhas))
print("Backup: caixa.py.bak")

# Gravar
with open(path, "w", encoding="utf-8") as f:
    f.write(novo_conteudo)

with open(path, encoding="utf-8") as f:
    linhas_novas = f.readlines()
print(f"Depois: {len(linhas_novas)} linhas")
print("OK - ficheiro corrigido")