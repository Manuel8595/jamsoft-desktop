"""
Melhoria 1: Adicionar funcao eliminar_transferencia + botao Eliminar.
Uso: python _ibt_melhoria_1_eliminar.py
"""

path = "transferencias.py"

with open(path, encoding="utf-8") as f:
    c = f.read()

# ============================================================
# 1. Adicionar funcao eliminar_transferencia
# ============================================================
funcao_eliminar = '''

def eliminar_transferencia(trans_id, utilizador_nome):
    """
    Elimina uma transferencia que esteja em RASCUNHO.
    Nao permite eliminar transferencias em outros estados.
    """
    conn = conectar()
    cur = conn.cursor()

    cur.execute("SELECT estado, referencia FROM transferencias_filiais WHERE id = ?",
                  (trans_id,))
    r = cur.fetchone()

    if not r:
        conn.close()
        return False, "Transferencia nao encontrada."

    estado, referencia = r

    if estado != ESTADO_RASCUNHO:
        conn.close()
        return False, f"Apenas RASCUNHOS podem ser eliminados. Estado actual: {estado}"

    # Eliminar itens e historico (CASCADE ja faz, mas garantimos)
    cur.execute("DELETE FROM itens_transferencia WHERE transferencia_id = ?",
                  (trans_id,))
    cur.execute("DELETE FROM historico_ibt WHERE transferencia_id = ?",
                  (trans_id,))
    cur.execute("DELETE FROM transferencias_filiais WHERE id = ?",
                  (trans_id,))

    conn.commit()
    conn.close()

    registar_auditoria(
        0, utilizador_nome,
        "IBT ELIMINADA",
        f"ID {trans_id} | {referencia} | RASCUNHO eliminado"
    )
    return True, f"Transferencia {referencia} eliminada."


def pode_editar_transferencia(trans_id):
    """
    Verifica se uma transferencia pode ser editada.
    So RASCUNHOS podem ser editados.
    Retorna (pode_editar: bool, estado: str)
    """
    conn = conectar()
    cur = conn.cursor()
    cur.execute("SELECT estado FROM transferencias_filiais WHERE id = ?",
                  (trans_id,))
    r = cur.fetchone()
    conn.close()

    if not r:
        return False, None

    return r[0] == ESTADO_RASCUNHO, r[0]

'''

# Inserir antes da funcao "def listar_transferencias"
marcador = "def listar_transferencias(estado=None, limite=100):"

if marcador in c and "def eliminar_transferencia" not in c:
    c = c.replace(marcador, funcao_eliminar.strip() + "\n\n\n" + marcador, 1)
    print("OK - funcao eliminar_transferencia adicionada")
elif "def eliminar_transferencia" in c:
    print("OK - funcao eliminar_transferencia ja existe")
else:
    print("AVISO - marcador 'def listar_transferencias' nao encontrado")

# ============================================================
# 2. Adicionar botao "Eliminar" na Lista IBT
# ============================================================
antigo_btn = '''    Button(frame_btn, text="❌ Fechar",
           bg=COR_VERMELHO,
           command=janela.destroy, **estilo).pack(side=RIGHT, padx=6, pady=15)'''

novo_btn = '''    Button(frame_btn, text="🗑️ Eliminar",
           bg="#7f1d1d", command=eliminar_rascunho, **estilo).pack(side=LEFT, padx=6, pady=15)
    Button(frame_btn, text="❌ Fechar",
           bg=COR_VERMELHO,
           command=janela.destroy, **estilo).pack(side=RIGHT, padx=6, pady=15)'''

if antigo_btn in c:
    c = c.replace(antigo_btn, novo_btn)
    print("OK - botao Eliminar adicionado")
else:
    print("AVISO - botao Fechar nao encontrado")

# ============================================================
# 3. Adicionar funcao eliminar_rascunho
# ============================================================
antigo_fn = '''    def continuar_rascunho():
        sel = tree.selection()
        if not sel:
            messagebox.showwarning("Aviso", "Selecione uma transferencia.")
            return
        tid = tree.item(sel[0])["values"][0]
        estado = tree.item(sel[0])["values"][8]
        if estado != ESTADO_RASCUNHO:
            messagebox.showinfo("Info",
                "Apenas RASCUNHOS podem ser continuados.\\n\\n"
                f"Estado actual: {estado}")
            return
        abrir_nova_ibt(utilizador, janela, callback=carregar,
                        trans_id_existente=tid)'''

nova_fn = antigo_fn + '''

    def eliminar_rascunho():
        sel = tree.selection()
        if not sel:
            messagebox.showwarning("Aviso", "Selecione uma transferencia.")
            return
        tid = tree.item(sel[0])["values"][0]
        ref = tree.item(sel[0])["values"][1]
        estado = tree.item(sel[0])["values"][8]

        if estado != ESTADO_RASCUNHO:
            messagebox.showinfo("Info",
                "Apenas RASCUNHOS podem ser eliminados.\\n\\n"
                f"Estado actual: {estado}\\n\\n"
                "Para cancelar uma IBT ja enviada, use 'Cancelar'.")
            return

        if not messagebox.askyesno("Eliminar Rascunho",
            f"Eliminar DEFINITIVAMENTE o rascunho {ref}?\\n\\n"
            "Esta accao nao pode ser revertida."):
            return

        sucesso, msg = eliminar_transferencia(tid, utilizador["nome"])
        if sucesso:
            messagebox.showinfo("Sucesso", f"✅ {msg}")
            carregar()
        else:
            messagebox.showerror("Erro", msg)'''

if antigo_fn in c:
    c = c.replace(antigo_fn, nova_fn)
    print("OK - funcao eliminar_rascunho adicionada")
else:
    print("AVISO - funcao continuar_rascunho nao encontrada (pode ter espacos diferentes)")

# ============================================================
# Gravar
# ============================================================
with open(path, "w", encoding="utf-8") as f:
    f.write(c)

print()
print("=" * 60)
print("OK - Melhoria 1 aplicada!")
print("=" * 60)